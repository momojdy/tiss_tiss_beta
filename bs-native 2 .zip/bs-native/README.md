# Wantiss Business Space (React Native / Expo)

`BusinessSpaceScreen.tsx` is the whole screen in one file: Home, charts, feature pages, listing wizard, panels, sheets, search handle,
registration, security and business information. Props are the same as before: `onSignOut`, `onSwitchToBuyer`.

## Install
```
npx expo install react-native-svg react-native-safe-area-context @react-native-async-storage/async-storage \
  expo-image-picker expo-image-manipulator expo-document-picker expo-file-system expo-notifications expo-device \
  expo-linking expo-web-browser @react-native-community/datetimepicker
npm i base64-arraybuffer
```
`@expo/vector-icons` and your `../../lib/supabase` client are already in your project. Place the file where that import path resolves.

## Environment
- `EXPO_PUBLIC_APP_URL` (default https://app.wantiss.com). `https://app.wantiss.com/business/payouts` must open the app (universal / app link) so payout setup returns to the Payouts panel.
- `EXPO_PUBLIC_SUPPORT_EMAIL` (default support@wantiss.com).

## Database (staging first, in order)
`migrations/001` to `005`. 005 adds: optional registration, per-feature requirements, 5-business limit and soft delete, custom date ranges with the previous
period, per-feature earnings, paged 120-day activity, payout rules (limits and fees you set), push tokens and data requests.
Payout limits and fees live in `payout_rules` (edit rows, no app update). Set `app_metadata.role = "admin"` on admin accounts.

## Edge functions
`supabase functions deploy payout-onboarding payout-webhook execute-payout send-push`
Secrets: STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, PAYOUT_WEBHOOK_SECRET, PUSH_WEBHOOK_SECRET, ALLOWED_RETURN_ORIGINS (https://app.wantiss.com), ALLOWED_RETURN_PATH (/business).
Database webhooks: INSERT on `wallet_ledger` -> `execute-payout` (header x-webhook-secret), INSERT on `notifications` -> `send-push` (header x-webhook-secret).
Stripe is shown as the example provider; swap the provider calls if you use another.

## Behaviour to know
- Registration is optional. The reminder is dismissible and returns each time the app is opened again.
- Publishing needs the feature's required requirements approved (declarations are recorded on the server; documents wait for the Admin app, which calls
  `admin_decide_requirement` and `admin_decide_verification`). Streamz and Bidz ID checks are needed before payouts.
- Payouts: standard, express, debit card and Wantiss wallet, enforced in `request_payout`. Wallet payouts are written to `wallet_transfers`
  for your wallet service to credit; it then calls `settle_payout`. The wallet's own withdrawal limits apply there.
- Konsoliss, Prezo and Frenzies are managed by Wantiss and are not vendor features.
- The Language setting saves the choice; translated strings are not included.

## Not run yet
Nothing here has been run on a device or a live Supabase project. Test on staging: sign-in, business switching, publishing with and without requirements, payouts,
refunds, cancellations, push, and the deep link.

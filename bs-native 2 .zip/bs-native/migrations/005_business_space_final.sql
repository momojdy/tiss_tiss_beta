-- Migration 005. Run after 001, 002, 003 and 004 on a clean staging project first.
-- Optional registration, per-feature requirements, 5-business limit and delete, custom date ranges with previous period,
-- per-feature earnings, paged activity, configurable payout rules with limits and fees, push tokens, data requests.

-- ===== business columns, soft delete =====
alter table businesses add column if not exists deleted_at timestamptz, add column if not exists phone_country text not null default 'NG';
grant update(phone_country) on businesses to authenticated;
alter table profiles add column if not exists language text not null default 'English';
alter table wallet_ledger add column if not exists method text;

-- Deleted businesses disappear from every policy that uses is_member().
create or replace function is_member(b uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from business_members m join businesses x on x.id=m.business_id where m.business_id=b and m.user_id=auth.uid() and x.deleted_at is null) $$;

-- ===== features managed by Wantiss are not vendor features =====
create or replace function platform_managed(f text) returns boolean language sql immutable as $$ select f in ('konsoliss','prezo','frenzies','topup') $$;
delete from feature_rules where feature in ('konsoliss','prezo','frenzies');
update feature_rules set required='{prize,prizeValue,ticket,total,drawAt,rules,eligible}' where feature='lutz';

create or replace function activate_feature(p_business uuid, p_feature text) returns void language plpgsql security definer set search_path=public as $$
declare v verification_status;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  if platform_managed(p_feature) then raise exception 'this feature is managed by Wantiss'; end if;
  if not exists(select 1 from status_transitions where feature=p_feature) then raise exception 'unknown feature'; end if;
  select verification into v from businesses where id=p_business;
  if v='restricted' then raise exception 'your business is restricted'; end if;
  insert into business_features(business_id, feature, status) values (p_business, p_feature, 'active') on conflict do nothing;
  perform log_event(p_business, p_feature, 'feature_activated', 'Feature activated: '||p_feature);
end $$;

-- ===== requirements: documents and declarations per feature (and optional business registration under '_business') =====
create table if not exists feature_requirements(
  id uuid primary key default gen_random_uuid(), feature text not null, country text, key text not null, label text not null,
  kind text not null check (kind in ('document','declaration')), required boolean not null default true, pay_gate boolean not null default false, note text, sort int not null default 0);
create unique index if not exists feature_req_uq on feature_requirements(feature, key, coalesce(country,''));
create table if not exists requirement_submissions(
  id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, requirement_id uuid not null references feature_requirements,
  status text not null check (status in ('submitted','approved','rejected')), file_path text, declared boolean not null default false, reason text,
  reviewed_by uuid, reviewed_at timestamptz, created_at timestamptz not null default now(), unique (business_id, requirement_id));
alter table feature_requirements enable row level security; alter table requirement_submissions enable row level security;
create policy "signed in read requirements" on feature_requirements for select to authenticated using (true);
create policy "members read submissions" on requirement_submissions for select using (is_member(business_id));

insert into feature_requirements(feature,key,label,kind,required,pay_gate,note,sort) values
 ('_business','registration','Business registration or trading licence','document',false,false,null,1),
 ('_business','owner_id','Owner ID (passport or national ID)','document',false,false,null,2),
 ('_business','address','Proof of business address','document',false,false,null,3),
 ('stayz','own','Proof you can list the property (ownership, lease or host authorisation)','document',true,false,null,1),
 ('stayz','id','Your ID','document',true,false,null,2),
 ('stayz','rules','I confirm the house rules','declaration',true,false,null,3),
 ('stayz','tour','Tourism licence','document',false,false,'Where the law requires one',4),
 ('flyz','auth','Travel agency or airline authorisation','document',true,false,null,1),
 ('flyz','id','Your ID','document',true,false,null,2),
 ('woulib','lic','Driver''s licence','document',true,false,null,1),
 ('woulib','reg','Vehicle registration','document',true,false,null,2),
 ('woulib','ins','Vehicle insurance','document',true,false,null,3),
 ('woulib','pol','Police clearance','document',false,false,'Required in some countries',4),
 ('rideza','reg','Vehicle registration','document',true,false,null,1),
 ('rideza','ins','Rental insurance','document',true,false,null,2),
 ('rideza','id','Your ID or business licence','document',true,false,null,3),
 ('habita','own','Proof of ownership or agent licence','document',true,false,null,1),
 ('habita','id','Your ID','document',true,false,null,2),
 ('services','id','Your ID','document',true,false,null,1),
 ('services','lic','Professional licence','document',false,false,'Required for regulated trades such as electrical, plumbing, legal or medical',2),
 ('arts','rights','I own the rights to this work','declaration',true,false,null,1),
 ('arts','cert','Certificate of authenticity','document',false,false,null,2),
 ('gatherz','id','Organiser ID','document',true,false,null,1),
 ('gatherz','permit','Event permit','document',false,false,'Required for large events where the law asks for one',2),
 ('glowz','id','Your ID','document',true,false,null,1),
 ('glowz','lic','Salon licence or health certificate','document',false,false,null,2),
 ('streamz','rights','I own or license the rights to this content','declaration',true,false,null,1),
 ('streamz','id','Your ID','document',true,true,'Needed before payouts',2),
 ('dealz','orig','The original price is genuine','declaration',true,false,null,1),
 ('globiz','reg','Company registration certificate','document',true,false,'Required for business-to-business offers',1),
 ('bidz','auth','Items are authentic as described','declaration',true,false,null,1),
 ('bidz','id','Your ID','document',true,true,'Needed before your first award',2),
 ('lutz','prize','Proof of the prize','document',true,false,null,1)
on conflict do nothing;

create or replace function feature_requirements_status(p_business uuid, p_feature text)
returns table(id uuid, key text, label text, kind text, required boolean, pay_gate boolean, note text, status text, file text, reason text)
language plpgsql stable security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query
    select fr.id, fr.key, fr.label, fr.kind, fr.required, fr.pay_gate, fr.note, coalesce(s.status,'missing'), s.file_path, s.reason
    from feature_requirements fr join businesses b on b.id=p_business
    left join requirement_submissions s on s.requirement_id=fr.id and s.business_id=p_business
    where fr.feature=p_feature and (fr.country is null or fr.country=b.country) order by fr.sort;
end $$;

-- Declarations are recorded with who confirmed them and when. Documents wait for review in the Admin app.
create or replace function submit_requirement(p_business uuid, p_requirement uuid, p_file text, p_declared boolean) returns void language plpgsql security definer set search_path=public as $$
declare r feature_requirements; v verification_status;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select verification into v from businesses where id=p_business;
  if v='restricted' then raise exception 'your business is restricted'; end if;
  select * into r from feature_requirements where id=p_requirement;
  if not found then raise exception 'unknown requirement'; end if;
  if r.kind='declaration' then
    if p_declared is not true then raise exception 'you need to confirm this'; end if;
    insert into requirement_submissions(business_id,requirement_id,status,declared) values (p_business,p_requirement,'approved',true)
      on conflict (business_id,requirement_id) do update set status='approved', declared=true, reason=null, reviewed_at=now();
  else
    if coalesce(p_file,'')='' then raise exception 'upload a file'; end if;
    if p_file not like p_business::text||'/%' then raise exception 'invalid file'; end if;
    insert into requirement_submissions(business_id,requirement_id,status,file_path) values (p_business,p_requirement,'submitted',p_file)
      on conflict (business_id,requirement_id) do update set status='submitted', file_path=excluded.file_path, reason=null, reviewed_by=null, reviewed_at=null, created_at=now();
  end if;
  perform log_event(p_business, case when r.feature='_business' then null else r.feature end, 'requirement_'||r.kind, r.label);
end $$;

create or replace function admin_decide_requirement(p_submission uuid, p_decision text, p_reason text default null) returns void language plpgsql security definer set search_path=public as $$
declare s requirement_submissions; r feature_requirements;
begin
  if not is_admin() then raise exception 'admins only'; end if;
  if p_decision not in ('approved','rejected') then raise exception 'bad decision'; end if;
  if p_decision='rejected' and coalesce(trim(p_reason),'')='' then raise exception 'give a reason'; end if;
  update requirement_submissions set status=p_decision, reason=p_reason, reviewed_by=auth.uid(), reviewed_at=now() where id=p_submission returning * into s;
  if not found then raise exception 'unknown submission'; end if;
  select * into r from feature_requirements where id=s.requirement_id;
  perform notify(s.business_id, case when r.feature='_business' then null else r.feature end, 'requirement', r.label||': '||p_decision, case when r.feature='_business' then '{"view":"onboard"}'::jsonb else jsonb_build_object('view','feat','arg',r.feature) end);
end $$;

create or replace function requirements_met(b uuid, f text) returns boolean language sql stable security definer set search_path=public as $$
  select not exists(select 1 from feature_requirements fr join businesses x on x.id=b
    left join requirement_submissions s on s.requirement_id=fr.id and s.business_id=b
    where fr.feature=f and fr.required and not fr.pay_gate and (fr.country is null or fr.country=x.country) and coalesce(s.status,'missing')<>'approved') $$;
create or replace function payout_gate_ok(b uuid) returns boolean language sql stable security definer set search_path=public as $$
  select not exists(select 1 from business_features bf join feature_requirements fr on fr.feature=bf.feature and fr.pay_gate
    left join requirement_submissions s on s.requirement_id=fr.id and s.business_id=b
    where bf.business_id=b and coalesce(s.status,'missing')<>'approved') $$;

-- ===== publishing no longer needs business verification; it needs the feature's own requirements =====
create or replace function publish_listing(p_listing uuid) returns text language plpgsql security definer set search_path=public as $$
declare l listings; b businesses; s text;
begin
  select * into l from listings where id=p_listing for update;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  select * into b from businesses where id=l.business_id;
  if b.verification='restricted' then raise exception 'your business is restricted'; end if;
  if platform_managed(l.feature) then raise exception 'this feature is managed by Wantiss'; end if;
  if not exists(select 1 from business_features where business_id=l.business_id and feature=l.feature and status<>'restricted') then raise exception 'activate % first', l.feature; end if;
  if l.status not in ('draft','paused','published','in_review') then raise exception 'this listing cannot be published from its current state'; end if;
  if coalesce(trim(l.title),'')='' then raise exception 'title is required'; end if;
  if not requirements_met(l.business_id, l.feature) then raise exception 'complete the requirements for this feature first'; end if;
  perform check_listing(l);
  s := case when l.feature='lutz' then 'in_review' when l.status='paused' then 'paused' else 'published' end;
  update listings set status=s where id=p_listing;
  perform log_event(l.business_id, l.feature, 'listing_'||s, l.title, jsonb_build_object('view','feat','arg',l.feature));
  return s;
end $$;

create or replace function go_live(p_business uuid) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  if (select verification from businesses where id=p_business)='restricted' then raise exception 'your business is restricted'; end if;
  if not exists(select 1 from business_features where business_id=p_business) then raise exception 'activate a feature first'; end if;
  if not exists(select 1 from listings where business_id=p_business and status<>'archived') then raise exception 'add a listing first'; end if;
  update businesses set is_live=true where id=p_business;
  perform log_event(p_business, null, 'went_live', 'Business went live');
end $$;

-- ===== at most 5 businesses per account; owners can delete =====
create or replace function create_business(p_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare b uuid;
begin
  if auth.uid() is null then raise exception 'sign in first'; end if;
  if length(trim(coalesce(p_name,''))) < 2 then raise exception 'enter a business name'; end if;
  perform pg_advisory_xact_lock(hashtext(auth.uid()::text));
  if (select count(*) from business_members m join businesses x on x.id=m.business_id where m.user_id=auth.uid() and m.role='owner' and x.deleted_at is null) >= 5 then raise exception 'You can have up to 5 businesses'; end if;
  insert into businesses(name) values (trim(p_name)) returning id into b;
  insert into business_members values (b, auth.uid(), 'owner');
  perform log_event(b, null, 'business_created', 'Business profile created');
  return b;
end $$;

create or replace function delete_business_check(p_business uuid) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare n int; av numeric; pe numeric; bl text[] := '{}';
begin
  if not is_owner(p_business) then raise exception 'only the owner can delete a business'; end if;
  select count(*) into n from feature_orders o where o.business_id=p_business and o.status<>'Cancelled' and not is_terminal(o.feature,o.status);
  if n>0 then bl := bl || (n||' open order'||case when n>1 then 's' else '' end||' or booking'||case when n>1 then 's' else '' end); end if;
  select coalesce(available,0), coalesce(pending,0) into av, pe from wallet_balance where business_id=p_business;
  if coalesce(av,0)>0 then bl := bl || ('Withdraw your available balance of '||av); end if;
  if coalesce(pe,0)>0 then bl := bl || ('Pending funds of '||pe||' are still settling'); end if;
  if exists(select 1 from wallet_ledger where business_id=p_business and type='payout' and status='processing') then bl := bl || 'A payout is still processing'; end if;
  return jsonb_build_object('blockers', to_jsonb(bl));
end $$;

create or replace function delete_business(p_business uuid, p_confirm text) returns void language plpgsql security definer set search_path=public as $$
declare b businesses;
begin
  if not is_owner(p_business) then raise exception 'only the owner can delete a business'; end if;
  select * into b from businesses where id=p_business for update;
  if trim(coalesce(p_confirm,'')) <> b.name then raise exception 'type the business name to confirm'; end if;
  if jsonb_array_length(delete_business_check(p_business)->'blockers') > 0 then raise exception 'resolve the open items first'; end if;
  perform log_event(p_business, null, 'business_deleted', 'Business deleted');
  update listings set status='archived' where business_id=p_business and status in ('published','paused','in_review','draft');
  update promotions set status='ended' where business_id=p_business and status in ('active','paused','in_review');
  update businesses set deleted_at=now(), is_live=false where id=p_business;
end $$;

-- ===== dashboard: any date range, previous period of equal length, per-feature earnings for every vendor feature =====
create or replace function dashboard_range(p_business uuid, p_from date, p_to date, p_feature text default null) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare days int; n int; pt date; pf date; rev numeric; prv numeric; gross numeric; fees numeric; refs numeric; av numeric; pe numeric; ser jsonb; pser jsonb; feats jsonb;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  if p_to < p_from or p_to - p_from > 730 then raise exception 'invalid range'; end if;
  days := p_to - p_from + 1; n := least(12, greatest(7, days)); pt := p_from - 1; pf := pt - (days - 1);
  select coalesce(sum(amount),0), coalesce(sum(amount) filter (where type='sale'),0), coalesce(sum(amount) filter (where type='fee'),0), coalesce(sum(amount) filter (where type='refund'),0)
    into rev, gross, fees, refs from wallet_ledger where business_id=p_business and type in ('sale','fee','refund') and status not in ('reversed','failed')
    and created_at >= p_from::timestamptz and created_at < (p_to+1)::timestamptz and (p_feature is null or feature=p_feature);
  select coalesce(sum(amount),0) into prv from wallet_ledger where business_id=p_business and type in ('sale','fee','refund') and status not in ('reversed','failed')
    and created_at >= pf::timestamptz and created_at < (pt+1)::timestamptz and (p_feature is null or feature=p_feature);
  select coalesce(available,0), coalesce(pending,0) into av, pe from wallet_balance where business_id=p_business;
  select coalesce(jsonb_agg(jsonb_build_object('d', x.d, 'v', x.v) order by x.i),'[]') into ser from (
    select g.i, (p_from + (days*g.i/n))::date as d, coalesce((select sum(l.amount) from wallet_ledger l where l.business_id=p_business and l.type in ('sale','fee','refund') and l.status not in ('reversed','failed')
      and (p_feature is null or l.feature=p_feature) and l.created_at >= (p_from + (days*g.i/n))::timestamptz and l.created_at < (p_from + (days*(g.i+1)/n))::timestamptz),0) as v
    from generate_series(0,n-1) g(i)) x;
  select coalesce(jsonb_agg(jsonb_build_object('d', x.d, 'v', x.v) order by x.i),'[]') into pser from (
    select g.i, (pf + (days*g.i/n))::date as d, coalesce((select sum(l.amount) from wallet_ledger l where l.business_id=p_business and l.type in ('sale','fee','refund') and l.status not in ('reversed','failed')
      and (p_feature is null or l.feature=p_feature) and l.created_at >= (pf + (days*g.i/n))::timestamptz and l.created_at < (pf + (days*(g.i+1)/n))::timestamptz),0) as v
    from generate_series(0,n-1) g(i)) x;
  select coalesce(jsonb_agg(jsonb_build_object('feature', f.feature, 'amount', coalesce(s.amt,0), 'orders', coalesce(o.cnt,0), 'fees', coalesce(s.fee,0)) order by coalesce(s.amt,0) desc, f.feature),'[]') into feats
  from fee_rules f
  left join (select feature, sum(amount) filter (where type='sale') amt, sum(amount) filter (where type='fee') fee from wallet_ledger where business_id=p_business and type in ('sale','fee') and status not in ('reversed','failed')
             and created_at >= p_from::timestamptz and created_at < (p_to+1)::timestamptz group by feature) s on s.feature=f.feature
  left join (select feature, count(*) cnt from feature_orders where business_id=p_business and status<>'Cancelled' and created_at >= p_from::timestamptz and created_at < (p_to+1)::timestamptz group by feature) o on o.feature=f.feature
  where not platform_managed(f.feature);
  return jsonb_build_object('revenue',rev,'prev_revenue',prv,'gross',gross,'fees',fees,'refunds',refs,'available',coalesce(av,0),'pending',coalesce(pe,0),'series',ser,'prev_series',pser,'features',feats);
end $$;

-- ===== activity: business events and money movements, newest first, last 120 days, paged by timestamp =====
create or replace function activity_feed(p_business uuid, p_days int default 120, p_before timestamptz default null, p_limit int default 30, p_kind text default null)
returns table(id text, at timestamptz, kind text, title text, feature text, amount numeric) language plpgsql stable security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query
    select x.xid, x.xat, x.xkind, x.xtitle, x.xfeature, x.xamount from (
      select 'a'||a.id::text as xid, a.at as xat, (case when a.kind like 'order%' then 'order' when a.kind like 'refund%' then 'refund' when a.kind like 'payout%' then 'payout' else 'other' end) as xkind, a.title as xtitle, a.feature as xfeature, null::numeric as xamount
        from business_activity a where a.business_id=p_business
      union all
      select 'w'||w.id::text, w.created_at, (case w.type::text when 'sale' then 'earn' when 'refund' then 'refund' when 'payout' then 'payout' else 'other' end), coalesce(w.label, initcap(w.type::text)), w.feature, w.amount
        from wallet_ledger w where w.business_id=p_business and w.type in ('sale','refund','payout')
    ) x
    where x.xat >= now() - make_interval(days => least(coalesce(p_days,120),120)) and (p_before is null or x.xat < p_before) and (p_kind is null or x.xkind = p_kind)
    order by x.xat desc limit least(coalesce(p_limit,30),100);
end $$;

-- ===== action required: no registration item (registration is optional) =====
create or replace function action_required(p_business uuid) returns table(kind text, feature text, label text, sub text, target text) language plpgsql stable security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query select 'orders', o.feature, 'Review '||count(*)||' new request'||case when count(*)>1 then 's' else '' end, o.feature, 'feature:'||o.feature
    from feature_orders o where o.business_id=p_business and o.status=first_status(o.feature) group by o.feature;
  return query select 'stock', l.feature, count(*)||' item'||case when count(*)>1 then 's' else '' end||' low on stock', l.feature, 'feature:'||l.feature
    from listings l where l.business_id=p_business and l.status='published' and l.stock is not null and l.stock <= coalesce((l.attributes->>'low')::int,3) group by l.feature;
  return query select 'requirements', bf.feature, 'Complete the requirements', bf.feature, 'requirements:'||bf.feature
    from business_features bf where bf.business_id=p_business and not platform_managed(bf.feature) and not requirements_met(p_business, bf.feature);
  return query select 'restricted', null::text, 'Contact support about your restriction', 'Support', 'registration' from businesses where id=p_business and verification='restricted';
  return query select 'messages', null::text, 'Reply to '||sum(unread_business)||' messages', 'Messages', 'messages' from conversations where business_id=p_business having coalesce(sum(unread_business),0)>0;
  return query select 'payout', null::text, 'Add payout method', 'Payments', 'payout' from businesses b where b.id=p_business and b.verification<>'restricted'
    and not exists(select 1 from payout_methods pm where pm.business_id=p_business and pm.status='verified');
end $$;

-- ===== payouts: rules in a table, limits and fees enforced here =====
create table if not exists payout_rules(method text primary key, name text not null, cap numeric not null default 0, window_days int not null default 0, fee numeric not null default 0 check (fee>=0 and fee<=0.5),
  eta text, needs_bank boolean not null default true, min_withdrawal numeric not null default 5, sort int not null default 0);
insert into payout_rules values
 ('std','Standard bank payout',100000,7,0,'Arrives within 14 days',true,5,1),
 ('exp','Express bank payout',3000000,1,0.035,'Same day',true,5,2),
 ('card','Debit card',10000,1,0,'',true,5,3),
 ('wal','Wantiss wallet',0,0,0,'',false,5,4) on conflict do nothing;
alter table payout_rules enable row level security;
create policy "signed in read payout rules" on payout_rules for select to authenticated using (true);
create table if not exists wallet_transfers(id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses, user_id uuid not null, ledger_id uuid not null references wallet_ledger,
  amount numeric(14,2) not null check (amount>0), status text not null default 'pending' check (status in ('pending','done','failed')), created_at timestamptz not null default now());
alter table wallet_transfers enable row level security;
create policy "members read wallet transfers" on wallet_transfers for select using (is_member(business_id));

create or replace function payout_usage(p_business uuid) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare r jsonb;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select coalesce(jsonb_object_agg(pr.method, coalesce(u.used,0)),'{}') into r from payout_rules pr
    left join lateral (select sum(-w.amount) as used from wallet_ledger w where w.business_id=p_business and w.type='payout' and w.method=pr.method and w.status not in ('failed','reversed')
      and pr.window_days>0 and w.created_at >= now() - make_interval(days => pr.window_days)) u on true;
  return r;
end $$;

drop function if exists request_payout(uuid, numeric, text);
create or replace function request_payout(b uuid, amt numeric, key text, method text) returns uuid language plpgsql security definer set search_path=public as $$
declare rule payout_rules; avail numeric; used numeric := 0; fee numeric; net numeric; rid uuid;
begin
  if not is_member(b) then raise exception 'not allowed'; end if;
  perform 1 from businesses where id=b for update;
  select id into rid from wallet_ledger where idempotency_key=key; if found then return rid; end if;
  if (select verification from businesses where id=b)='restricted' then raise exception 'payouts are paused while your business is restricted'; end if;
  select * into rule from payout_rules where payout_rules.method=request_payout.method; if not found then raise exception 'unknown payout method'; end if;
  if rule.needs_bank and not exists(select 1 from payout_methods where business_id=b and status='verified') then raise exception 'set up a payout method first'; end if;
  if not payout_gate_ok(b) then raise exception 'complete the identity requirement for your features before withdrawing'; end if;
  if amt is null or amt < rule.min_withdrawal then raise exception 'minimum withdrawal is %', rule.min_withdrawal; end if;
  select coalesce(available,0) into avail from wallet_balance where business_id=b;
  if amt > coalesce(avail,0) then raise exception 'amount exceeds your available balance'; end if;
  if rule.cap > 0 then
    select coalesce(sum(-w.amount),0) into used from wallet_ledger w where w.business_id=b and w.type='payout' and w.method=rule.method and w.status not in ('failed','reversed') and w.created_at >= now() - make_interval(days => rule.window_days);
    if used + amt > rule.cap then raise exception 'above your limit. You can withdraw % more', greatest(0, rule.cap - used); end if;
  end if;
  fee := round(amt * rule.fee, 2); net := amt - fee;
  insert into wallet_ledger(business_id,type,status,amount,idempotency_key,label,method) values (b,'payout','processing',-net,key,'Payout · '||rule.name,rule.method) returning id into rid;
  if fee > 0 then insert into wallet_ledger(business_id,type,status,amount,idempotency_key,label) values (b,'fee','posted',-fee,key||'-fee',rule.name||' fee'); end if;
  if rule.method = 'wal' then insert into wallet_transfers(business_id,user_id,ledger_id,amount) values (b, auth.uid(), rid, net); end if;
  perform log_event(b, null, 'payout_requested', 'Payout requested: '||amt||' to '||rule.name);
  return rid;
end $$;

-- ===== push tokens and data requests =====
create table if not exists push_tokens(user_id uuid not null references auth.users on delete cascade, token text not null, platform text, updated_at timestamptz not null default now(), primary key (user_id, token));
alter table push_tokens enable row level security;
create or replace function register_push_token(p_token text, p_platform text) returns void language sql security definer set search_path=public as $$
  insert into push_tokens(user_id, token, platform) values (auth.uid(), p_token, p_platform) on conflict (user_id, token) do update set updated_at=now(), platform=excluded.platform $$;

create table if not exists data_requests(id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users on delete cascade, kind text not null check (kind in ('export','delete')), status text not null default 'pending', created_at timestamptz not null default now());
alter table data_requests enable row level security;
create policy "own data requests" on data_requests for select using (user_id = auth.uid());
create or replace function request_data_action(p_kind text) returns void language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'sign in first'; end if;
  if p_kind not in ('export','delete') then raise exception 'unknown request'; end if;
  if p_kind='delete' and exists(select 1 from business_members m join businesses x on x.id=m.business_id where m.user_id=auth.uid() and m.role='owner' and x.deleted_at is null) then raise exception 'delete your businesses first. They must have no open orders or balances'; end if;
  if exists(select 1 from data_requests where user_id=auth.uid() and kind=p_kind and status='pending') then return; end if;
  insert into data_requests(user_id, kind) values (auth.uid(), p_kind);
end $$;

-- ===== privileges =====
do $$ declare r record;
begin
  for r in select p.oid::regprocedure as sig, p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'
    and p.proname in ('is_member','activate_feature','feature_requirements_status','submit_requirement','admin_decide_requirement','requirements_met','payout_gate_ok','publish_listing','go_live','create_business','delete_business_check','delete_business','dashboard_range','activity_feed','action_required','payout_usage','request_payout','register_push_token','request_data_action','platform_managed') loop
    execute format('revoke all on function %s from public, anon, authenticated', r.sig);
    if r.proname not in ('requirements_met','payout_gate_ok') then execute format('grant execute on function %s to authenticated', r.sig); end if;
    execute format('grant execute on function %s to service_role', r.sig);
  end loop;
end $$;
revoke all on all tables in schema public from anon;
do $$ begin alter publication supabase_realtime add table payout_methods; exception when duplicate_object then null; end $$;

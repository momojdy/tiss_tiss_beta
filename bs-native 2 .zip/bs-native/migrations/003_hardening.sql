-- Migration 003: security and integrity hardening. Run after 001 and 002.
-- Review findings addressed: membership RLS, stock reservation, private documents, payout provider + concurrency,
-- ledger integrity, exposed helper functions, notification and listing permissions, conversation privacy,
-- server-side listing validation, feature-specific booking tables with real constraints, inventory variants.

create extension if not exists btree_gist;

-- ===== A. Members must be able to read their own membership rows =====
create policy "read own memberships" on business_members for select using (user_id = auth.uid());

-- The balance view must respect RLS (otherwise it exposes every business's balance).
alter view wallet_balance set (security_invoker = true);

-- ===== Business profile fields (editable by members; protected fields stay locked) =====
alter table businesses add column if not exists description text, add column if not exists phone text, add column if not exists email text,
  add column if not exists address text, add column if not exists city text, add column if not exists country text,
  add column if not exists hours jsonb not null default '{}', add column if not exists delivery_modes text[] not null default '{}';
grant update(name, logo_url, description, phone, email, address, city, country, hours, delivery_modes) on businesses to authenticated;

-- ===== D. Payouts go through a payment provider; bank details never touch our database =====
alter table payout_methods alter column holder drop not null, alter column last4 drop not null;
alter table payout_methods add column if not exists provider text, add column if not exists provider_account_id text unique,
  add column if not exists status text not null default 'pending' check (status in ('pending','verified','failed'));
drop function if exists save_payout_method(uuid, text, text, text);

-- Called only by the provider webhook (service role) once the destination is verified.
create or replace function confirm_payout_method(p_account text, p_last4 text default null) returns void language plpgsql security definer set search_path=public as $$
declare b uuid;
begin
  update payout_methods set status='verified', last4=coalesce(p_last4,last4) where provider_account_id=p_account returning business_id into b;
  if b is null then raise exception 'unknown payout account'; end if;
  update businesses set payout_ready=true where id=b;
  perform log_event(b, null, 'payout_method_verified', 'Payout method verified');
  perform notify(b, null, 'payout', 'Your payout method is verified', '{"view":"wallet"}');
end $$;

-- Called only by the payout executor / provider webhook (service role).
create or replace function settle_payout(p_ledger uuid, p_status text) returns void language plpgsql security definer set search_path=public as $$
declare w wallet_ledger;
begin
  if p_status not in ('completed','failed') then raise exception 'bad status'; end if;
  update wallet_ledger set status=p_status::ledger_status where id=p_ledger and type='payout' and status='processing' returning * into w;
  if not found then return; end if;
  perform notify(w.business_id, null, 'payout', case when p_status='completed' then 'Payout completed' else 'Payout failed. Funds are back in your balance.' end, '{"view":"wallet"}');
  perform log_event(w.business_id, null, 'payout_'||p_status, 'Payout '||p_status);
end $$;

-- ===== E. Payout requests are serialized per business, then checked against a verified destination =====
create or replace function request_payout(b uuid, amt numeric, key text) returns uuid language plpgsql security definer set search_path=public as $$
declare avail numeric; rid uuid;
begin
  if not is_member(b) then raise exception 'not allowed'; end if;
  perform 1 from businesses where id=b for update;                       -- row lock: concurrent payouts and refunds queue up
  select id into rid from wallet_ledger where idempotency_key=key; if found then return rid; end if;
  if not (select payout_ready and verification='verified' from businesses where id=b) then raise exception 'payouts are not available yet'; end if;
  if not exists(select 1 from payout_methods where business_id=b and status='verified') then raise exception 'no verified payout method'; end if;
  select coalesce(available,0) into avail from wallet_balance where business_id=b;
  if amt<=0 or amt>avail then raise exception 'amount exceeds your available balance'; end if;
  insert into wallet_ledger(business_id,type,status,amount,idempotency_key,label) values (b,'payout','processing',-amt,key,'Payout') returning id into rid;
  perform log_event(b, null, 'payout_requested', 'Payout requested: '||amt);
  return rid;
end $$;

-- ===== Refunds: reverse the fee that was actually charged, under the same lock =====
create or replace function refund_order(p_order uuid, p_amount numeric, p_key text) returns uuid language plpgsql security definer set search_path=public as $$
declare o feature_orders; rid uuid; sold numeric; fee_paid numeric; fee numeric;
begin
  select id into rid from wallet_ledger where idempotency_key=p_key; if found then return rid; end if;
  select * into o from feature_orders where id=p_order;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  perform 1 from businesses where id=o.business_id for update;
  select * into o from feature_orders where id=p_order for update;
  if p_amount <= 0 or p_amount > o.amount - o.refunded then raise exception 'refund exceeds the refundable amount'; end if;
  if o.status = first_status(o.feature) then raise exception 'accept or cancel the order before refunding'; end if;
  select coalesce(sum(amount) filter (where type='sale'),0), coalesce(-sum(amount) filter (where type='fee' and amount<0),0) into sold, fee_paid from wallet_ledger where ref_table='feature_orders' and ref_id=o.id;
  fee := case when sold>0 then round(p_amount * fee_paid / sold, 2) else 0 end;
  insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,idempotency_key,label) values (o.business_id,o.feature,'refund','posted',-p_amount,'feature_orders',o.id,p_key,'Refund · '||coalesce(o.title,'order')) returning id into rid;
  if fee > 0 then insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,label) values (o.business_id,o.feature,'fee','posted',fee,'feature_orders',o.id,'Platform fee reversal'); end if;
  update feature_orders set refunded=refunded+p_amount where id=p_order;
  perform log_event(o.business_id, o.feature, 'refund', 'Refunded '||p_amount||' on '||coalesce(o.title,'order'));
  return rid;
end $$;

-- ===== Ledger integrity: append-only, amounts never change, status only moves forward =====
create or replace function trg_ledger_guard() returns trigger language plpgsql as $$
begin
  if tg_op='DELETE' then raise exception 'ledger entries cannot be deleted'; end if;
  if new.amount<>old.amount or new.type<>old.type or new.business_id<>old.business_id or new.ref_id is distinct from old.ref_id then raise exception 'ledger entries are immutable'; end if;
  if new.status<>old.status and not ((old.status='pending' and new.status in ('posted','failed','reversed')) or (old.status='processing' and new.status in ('completed','failed')) or (old.status='posted' and new.status='reversed')) then raise exception 'invalid ledger status change'; end if;
  return new;
end $$;
create trigger ledger_guard before update or delete on wallet_ledger for each row execute function trg_ledger_guard();

-- ===== B. Inventory: atomic reservation (trusted checkout only) and audited adjustments =====
drop function if exists reserve_stock(uuid, int);
create table if not exists listing_variants(id uuid primary key default gen_random_uuid(), listing_id uuid not null references listings on delete cascade,
  name text not null, value text not null, price numeric(14,2) check (price is null or price>=0), stock int check (stock is null or stock>=0), unique(listing_id,name,value));
create table if not exists stock_adjustments(id bigserial primary key, listing_id uuid not null references listings, variant_id uuid references listing_variants, delta int not null, reason text not null, actor_id uuid, at timestamptz default now());

create or replace function reserve_stock(p_listing uuid, p_variant uuid, p_qty int) returns boolean language plpgsql security definer set search_path=public as $$
begin
  if p_qty is null or p_qty <= 0 then raise exception 'quantity must be positive'; end if;
  if p_variant is not null then
    update listing_variants v set stock = v.stock - p_qty from listings l where v.id=p_variant and v.listing_id=p_listing and l.id=v.listing_id and l.status='published' and v.stock is not null and v.stock >= p_qty;
  else
    update listings set stock = stock - p_qty where id=p_listing and status='published' and stock is not null and stock >= p_qty;
  end if;
  return found;
end $$;

create or replace function adjust_stock(p_listing uuid, p_variant uuid, p_delta int, p_reason text) returns int language plpgsql security definer set search_path=public as $$
declare l listings; n int;
begin
  select * into l from listings where id=p_listing for update;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  if p_delta = 0 or trim(coalesce(p_reason,''))='' then raise exception 'enter a change and a reason'; end if;
  if p_variant is not null then
    update listing_variants set stock = stock + p_delta where id=p_variant and listing_id=p_listing and stock is not null returning stock into n;
  else
    update listings set stock = stock + p_delta where id=p_listing and stock is not null returning stock into n;
  end if;
  if n is null then raise exception 'stock is not tracked for this item'; end if;   -- the check constraint also blocks negative stock
  insert into stock_adjustments(listing_id,variant_id,delta,reason,actor_id) values (p_listing,p_variant,p_delta,p_reason,auth.uid());
  perform log_event(l.business_id, l.feature, 'stock_adjusted', l.title||': '||p_delta||' ('||p_reason||')');
  return n;
end $$;

-- Initial stock and variants are set while a listing is still a draft; afterwards only adjust_stock can change them.
create or replace function set_draft_stock(p_listing uuid, p_stock int, p_variants jsonb) returns void language plpgsql security definer set search_path=public as $$
declare l listings; r jsonb;
begin
  select * into l from listings where id=p_listing for update;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  if l.status<>'draft' then raise exception 'use stock adjustments on live listings'; end if;
  update listings set stock = p_stock where id=p_listing;
  delete from listing_variants where listing_id=p_listing and (name,value) not in (select x->>'name', x->>'value' from jsonb_array_elements(coalesce(p_variants,'[]')) x);
  for r in select * from jsonb_array_elements(coalesce(p_variants,'[]')) loop
    if coalesce(r->>'name','')='' or coalesce(r->>'value','')='' then continue; end if;
    insert into listing_variants(listing_id,name,value,price,stock) values (p_listing,r->>'name',r->>'value',nullif(r->>'price','')::numeric,nullif(r->>'qty','')::int)
      on conflict (listing_id,name,value) do update set price=excluded.price, stock=excluded.stock;
  end loop;
end $$;
revoke update(stock) on listings from authenticated;

-- ===== Server-side listing validation (the client rules are only a convenience) =====
create table if not exists feature_rules(feature text primary key, required text[] not null default '{}', min_photos int not null default 1, needs_price boolean not null default false);
insert into feature_rules values
 ('goodies', '{condition}', 1, true), ('stayz','{ptype,address,city,country,guests,cancel}',5,true), ('flyz','{airline,flightNo,from,to,dep,arr,cabin}',0,true),
 ('woulib','{service,vehicle,plate,city,radius,base,perKm}',2,false), ('rideza','{make,model,year,type,trans,fuel,plate,deposit,location}',4,true),
 ('habita','{mode,ptype,address,city,country,area,agent,phone}',5,true), ('services','{model,where}',1,false), ('arts','{kind,creator}',1,true),
 ('gatherz','{start,end}',1,false), ('glowz','{where,duration}',1,true), ('streamz','{type,model}',1,false), ('dealz','{original,start,end,terms}',1,true),
 ('prezo','{occasions}',2,true), ('globiz','{type,contact,phone,city}',1,false), ('bidz','{start,inc,startAt,hours,condition}',3,false),
 ('lutz','{prize,prizeValue,ticket,total,drawAt,rules,permit}',2,false), ('konsoliss','{mode,origin,dest,cutoff,etd,eta,container,cbm,perCbm}',0,false),
 ('frenzies','{game,format,entry,players,prize,regClose,start,rules}',1,false)
 on conflict (feature) do nothing;

create or replace function check_listing(l listings) returns void language plpgsql stable as $$
declare r feature_rules; k text; a jsonb := l.attributes;
begin
  select * into r from feature_rules where feature=l.feature;
  if not found then raise exception 'unknown feature'; end if;
  if coalesce(array_length(l.photos,1),0) < r.min_photos then raise exception 'add at least % photos', r.min_photos; end if;
  if r.needs_price and coalesce(l.price,0) <= 0 then raise exception 'set a price'; end if;
  foreach k in array r.required loop
    if a->k is null or a->>k = '' or a->k = '[]'::jsonb then raise exception 'missing field: %', k; end if;
  end loop;
  if l.feature='dealz' and l.price >= (a->>'original')::numeric then raise exception 'deal price must be below the original price'; end if;
  if l.feature='dealz' and (a->>'end')::timestamptz <= (a->>'start')::timestamptz then raise exception 'end must be after start'; end if;
  if l.feature='bidz' and (a->>'reserve') is not null and (a->>'reserve')::numeric < (a->>'start')::numeric then raise exception 'reserve cannot be below the starting bid'; end if;
  if l.feature='flyz' and (a->>'arr')::timestamptz <= (a->>'dep')::timestamptz then raise exception 'arrival must be after departure'; end if;
  if l.feature='flyz' and upper(a->>'from') = upper(a->>'to') then raise exception 'destination must differ from origin'; end if;
  if l.feature='gatherz' and (a->>'end')::timestamptz <= (a->>'start')::timestamptz then raise exception 'event must end after it starts'; end if;
  if l.feature='gatherz' and jsonb_array_length(coalesce(a->'tiers','[]'))=0 then raise exception 'add at least one ticket tier'; end if;
  if l.feature='konsoliss' and ((a->>'etd')::timestamptz <= (a->>'cutoff')::timestamptz or (a->>'eta')::timestamptz <= (a->>'etd')::timestamptz) then raise exception 'check the cut-off, departure and arrival dates'; end if;
  if l.feature='lutz' and (a->>'drawAt')::timestamptz <= now() then raise exception 'draw date must be in the future'; end if;
  if l.feature in ('lutz','frenzies') and coalesce((a->>'age')::boolean,false) is not true then raise exception 'the 18+ confirmation is required'; end if;
  if l.feature='streamz' and coalesce((a->>'rights')::boolean,false) is not true then raise exception 'confirm you hold the rights'; end if;
end $$;

create or replace function publish_listing(p_listing uuid) returns text language plpgsql security definer set search_path=public as $$
declare l listings; b businesses; s text;
begin
  select * into l from listings where id=p_listing for update;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  select * into b from businesses where id=l.business_id;
  if b.verification<>'verified' then raise exception 'your business must be verified before publishing'; end if;
  if not exists(select 1 from business_features where business_id=l.business_id and feature=l.feature and status<>'restricted') then raise exception 'activate % first', l.feature; end if;
  if l.status not in ('draft','paused') then raise exception 'this listing cannot be published from its current state'; end if;
  if coalesce(trim(l.title),'')='' then raise exception 'title is required'; end if;
  perform check_listing(l);
  s := case when l.feature in ('lutz','frenzies') then 'in_review' else 'published' end;
  update listings set status=s where id=p_listing;
  perform log_event(l.business_id, l.feature, 'listing_'||s, l.title, jsonb_build_object('view','feat','arg',l.feature));
  return s;
end $$;

-- Material edits to a live raffle or tournament send it back to review.
create or replace function trg_reapprove() returns trigger language plpgsql as $$
begin
  if new.feature in ('lutz','frenzies') and old.status='published' and (new.attributes is distinct from old.attributes or new.price is distinct from old.price or new.title is distinct from old.title) then new.status := 'in_review'; end if;
  return new;
end $$;
create trigger listings_reapprove before update on listings for each row execute function trg_reapprove();

-- ===== Feature-specific booking records (shared header in feature_orders, domain rules per feature) =====
create table if not exists stayz_bookings(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings,
  stay daterange not null, guests int not null check (guests>0), active boolean not null default true,
  constraint no_double_stay exclude using gist (listing_id with =, stay with &&) where (active));
create table if not exists rideza_reservations(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings,
  period daterange not null, active boolean not null default true,
  constraint no_double_rental exclude using gist (listing_id with =, period with &&) where (active));
create table if not exists woulib_trips(order_id uuid primary key references feature_orders on delete cascade, service_id uuid references listings,
  pickup text not null, dropoff text, distance_km numeric, driver_id uuid, fare numeric(12,2));
create table if not exists konsoliss_shipments(order_id uuid primary key references feature_orders on delete cascade, route_id uuid not null references listings,
  cbm numeric(10,3) not null check (cbm>0), kg numeric(12,2));

create or replace function trg_blocked_stay() returns trigger language plpgsql as $$
begin
  if exists(select 1 from listings l, jsonb_array_elements_text(coalesce(l.attributes->'blocked','[]')) d where l.id=new.listing_id and d::date <@ new.stay) then raise exception 'those dates are blocked by the host'; end if;
  return new;
end $$;
create or replace function trg_blocked_rental() returns trigger language plpgsql as $$
begin
  if exists(select 1 from listings l, jsonb_array_elements_text(coalesce(l.attributes->'blocked','[]')) d where l.id=new.listing_id and d::date <@ new.period) then raise exception 'those dates are blocked by the owner'; end if;
  return new;
end $$;
create trigger stayz_blocked before insert on stayz_bookings for each row execute function trg_blocked_stay();
create trigger rideza_blocked before insert on rideza_reservations for each row execute function trg_blocked_rental();

create or replace function trg_capacity() returns trigger language plpgsql as $$
declare cap numeric; used numeric;
begin
  select (attributes->>'cbm')::numeric into cap from listings where id=new.route_id for update;
  select coalesce(sum(cbm),0) into used from konsoliss_shipments where route_id=new.route_id;
  if used + new.cbm > cap then raise exception 'not enough space left on this route'; end if;
  return new;
end $$;
create trigger konsoliss_capacity before insert on konsoliss_shipments for each row execute function trg_capacity();

alter table stayz_bookings enable row level security; alter table rideza_reservations enable row level security; alter table woulib_trips enable row level security; alter table konsoliss_shipments enable row level security; alter table listing_variants enable row level security; alter table stock_adjustments enable row level security;
create policy "members read stayz" on stayz_bookings for select using (exists(select 1 from feature_orders o where o.id=order_id and is_member(o.business_id)));
create policy "members read rideza" on rideza_reservations for select using (exists(select 1 from feature_orders o where o.id=order_id and is_member(o.business_id)));
create policy "members read woulib" on woulib_trips for select using (exists(select 1 from feature_orders o where o.id=order_id and is_member(o.business_id)));
create policy "members read konsoliss" on konsoliss_shipments for select using (exists(select 1 from feature_orders o where o.id=order_id and is_member(o.business_id)));
create policy "members read variants" on listing_variants for select using (exists(select 1 from listings l where l.id=listing_id and is_member(l.business_id)));
create policy "members read adjustments" on stock_adjustments for select using (exists(select 1 from listings l where l.id=listing_id and is_member(l.business_id)));

-- ===== Notifications: members can only mark their own as read, through a function =====
drop policy if exists "members update notifications" on notifications;
revoke update on notifications from authenticated;
drop policy if exists "members read notifications" on notifications;
create policy "read own notifications" on notifications for select using (user_id = auth.uid() and is_member(business_id));
create or replace function mark_notification_read(p_id uuid) returns void language sql security definer set search_path=public as $$
  update notifications set read_at=now() where id=p_id and user_id=auth.uid() and read_at is null $$;
create or replace function mark_notifications_read(p_business uuid) returns void language sql security definer set search_path=public as $$
  update notifications set read_at=now() where business_id=p_business and user_id=auth.uid() and read_at is null $$;

-- ===== Conversations: both sides are participants; neither sees the other's other conversations =====
create policy "customers read own conversations" on conversations for select using (customer_id = auth.uid());
create policy "customers read own messages" on messages for select using (exists(select 1 from conversations c where c.id=conversation_id and c.customer_id=auth.uid()));
create policy "customers send messages" on messages for insert with check (sender_id=auth.uid() and exists(select 1 from conversations c where c.id=conversation_id and c.customer_id=auth.uid()));

-- ===== C. Private documents: members can upload, only reviewers (admins) can read; submitted proofs cannot be deleted =====
drop policy if exists "members read private files" on storage.objects;
drop policy if exists "members delete files" on storage.objects;
create policy "members read creator media" on storage.objects for select using (bucket_id='creator-media' and is_member(((storage.foldername(name))[1])::uuid));
create policy "admins read business docs" on storage.objects for select using (bucket_id='business-docs' and is_admin());
create or replace function can_delete_file(p_bucket text, p_name text) returns boolean language sql stable security definer set search_path=public as $$
  select is_member(((storage.foldername(p_name))[1])::uuid) and not (p_bucket='business-docs' and (storage.foldername(p_name))[2]='verification'
    and (select verification from businesses where id=((storage.foldername(p_name))[1])::uuid) in ('pending','verified')) $$;
create policy "members delete files" on storage.objects for delete using (bucket_id in ('listing-photos','business-docs','creator-media') and can_delete_file(bucket_id, name));
create policy "admins delete docs" on storage.objects for delete using (bucket_id='business-docs' and is_admin());

-- ===== Search results carry the exact record id =====
drop function if exists search_business(uuid, text);
create or replace function search_business(p_business uuid, p_q text) returns table(scope text, title text, sub text, feature text, target text, rec_id uuid) language plpgsql stable security definer set search_path=public as $$
declare q text := '%'||replace(replace(p_q,'%','\%'),'_','\_')||'%';
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query select 'Listings', l.title, 'Listing · '||l.status, l.feature, 'listing', l.id from listings l where l.business_id=p_business and l.title ilike q limit 8;
  return query select 'Orders', coalesce(o.title,'Order'), 'Order · '||o.status, o.feature, 'order', o.id from feature_orders o where o.business_id=p_business and (o.title ilike q or o.id::text ilike q) limit 8;
  return query select 'Customers', o.customer_name, 'Customer · '||coalesce(o.title,''), o.feature, 'order', o.id from feature_orders o where o.business_id=p_business and o.customer_name ilike q limit 5;
  return query select 'Promotions', p.title, 'Promotion · '||p.status, p.feature, 'promo', p.id from promotions p where p.business_id=p_business and p.title ilike q limit 5;
  return query select 'Money', coalesce(w.label,w.type::text), 'Transaction · '||w.status, coalesce(w.feature,'goodies'), 'wallet', w.id from wallet_ledger w where w.business_id=p_business and (w.label ilike q or w.type::text ilike q) order by w.created_at desc limit 5;
end $$;

-- ===== Function privileges: nothing is callable by anonymous users; internal helpers are not callable by clients at all =====
do $$ declare r record;
begin
  for r in select p.oid::regprocedure as sig, p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.prosecdef loop
    execute format('revoke all on function %s from public, anon, authenticated', r.sig);
    if r.proname in ('is_member','is_admin','can_delete_file','create_business','submit_verification','admin_decide_verification','activate_feature','deactivate_feature','go_live',
      'create_draft','publish_listing','set_listing_status','set_draft_stock','adjust_stock','advance_order','refund_order','request_payout','dashboard_summary','earnings_breakdown',
      'action_required','search_business','mark_notifications_read','mark_notification_read','mark_conversation_read','set_promotion_status') then
      execute format('grant execute on function %s to authenticated', r.sig);
    end if;
    -- service_role only: log_event, notify, reserve_stock, confirm_payout_method, settle_payout
    execute format('grant execute on function %s to service_role', r.sig);
  end loop;
end $$;
revoke all on all tables in schema public from anon;

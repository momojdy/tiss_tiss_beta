-- Wantiss Business Space: core Supabase schema, RLS and trusted functions (starting point)
create type verification_status as enum ('setup','pending','action','restricted','verified');
create type ledger_type as enum ('sale','fee','refund','adjustment','payout');
create type ledger_status as enum ('pending','posted','processing','completed','failed','reversed');

create table businesses(id uuid primary key default gen_random_uuid(), name text not null, logo_url text,
  verification verification_status not null default 'setup', payout_ready boolean not null default false,
  is_live boolean not null default false, created_at timestamptz default now());
create table business_members(business_id uuid references businesses on delete cascade, user_id uuid references auth.users on delete cascade,
  role text not null default 'owner' check (role in ('owner','manager','staff')), primary key(business_id,user_id));
create table business_features(business_id uuid references businesses on delete cascade, feature text not null, status text not null default 'setup'
  check (status in ('setup','active','restricted')), primary key(business_id,feature)); -- feature: goodies, stayz, woulib, rideza, ...
create table verification_requests(id uuid primary key default gen_random_uuid(), business_id uuid references businesses, documents jsonb, decision text, decided_by uuid, decided_at timestamptz);

-- Feature-specific records live in their own tables (goodies_orders, stayz_bookings, woulib_trips, rideza_reservations, ...), each with
-- business_id, its own status enum and a transition trigger. Never one generic order table.

create table wallet_ledger(id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses, feature text,
  type ledger_type not null, status ledger_status not null, amount numeric(14,2) not null, ref_table text, ref_id uuid,
  idempotency_key text unique, created_at timestamptz default now());
create table notifications(id uuid primary key default gen_random_uuid(), business_id uuid references businesses, user_id uuid, kind text, title text, link jsonb, read_at timestamptz, created_at timestamptz default now());
create table conversations(id uuid primary key default gen_random_uuid(), business_id uuid references businesses, customer_id uuid, feature text, ref_table text, ref_id uuid);
create table messages(id uuid primary key default gen_random_uuid(), conversation_id uuid references conversations on delete cascade, sender_id uuid, body text, created_at timestamptz default now());
create table promotions(id uuid primary key default gen_random_uuid(), business_id uuid references businesses, funded_by text check (funded_by in ('vendor','platform')), feature text, title text, status text default 'in_review');
create table audit_log(id bigserial primary key, business_id uuid, actor_id uuid, action text, ref_table text, ref_id text, meta jsonb, at timestamptz default now());

create function is_member(b uuid) returns boolean language sql stable security definer as
$$ select exists(select 1 from business_members where business_id=b and user_id=auth.uid()) $$;

alter table businesses enable row level security; alter table business_members enable row level security; alter table business_features enable row level security;
alter table wallet_ledger enable row level security; alter table notifications enable row level security; alter table conversations enable row level security;
alter table messages enable row level security; alter table promotions enable row level security; alter table audit_log enable row level security;

create policy "members read business" on businesses for select using (is_member(id));
create policy "members edit profile fields" on businesses for update using (is_member(id)); -- column grants block verification/payout_ready/is_live
revoke update(verification, payout_ready, is_live) on businesses from authenticated;
create policy "members read features" on business_features for select using (is_member(business_id));
create policy "members read ledger" on wallet_ledger for select using (is_member(business_id)); -- no insert/update policy: writes only via security definer functions
create policy "members read notifications" on notifications for select using (is_member(business_id));
create policy "members read conversations" on conversations for select using (is_member(business_id));
create policy "members read messages" on messages for select using (exists(select 1 from conversations c where c.id=conversation_id and is_member(c.business_id)));
create policy "members read promotions" on promotions for select using (is_member(business_id));
create policy "members read audit" on audit_log for select using (is_member(business_id));

-- Balances are computed server-side; the client never sends a balance.
create view wallet_balance as select business_id,
  sum(amount) filter (where status in ('posted','processing','completed')) as available,
  sum(amount) filter (where status='pending' and type<>'payout') as pending
  from wallet_ledger group by business_id;

-- Payout request: trusted and idempotent (retries return the original row).
create function request_payout(b uuid, amt numeric, key text) returns uuid language plpgsql security definer as $$
declare avail numeric; rid uuid;
begin
  if not is_member(b) then raise exception 'not allowed'; end if;
  select id into rid from wallet_ledger where idempotency_key=key; if found then return rid; end if;
  if not (select payout_ready and verification='verified' from businesses where id=b) then raise exception 'payout not available'; end if;
  select coalesce(available,0) into avail from wallet_balance where business_id=b;
  if amt<=0 or amt>avail then raise exception 'amount exceeds available balance'; end if;
  insert into wallet_ledger(business_id,type,status,amount,idempotency_key) values(b,'payout','processing',-amt,key) returning id into rid;
  insert into audit_log(business_id,actor_id,action,ref_table,ref_id) values(b,auth.uid(),'payout_requested','wallet_ledger',rid::text);
  return rid;
end $$;

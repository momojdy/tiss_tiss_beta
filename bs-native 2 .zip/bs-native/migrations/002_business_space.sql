-- Wantiss Business Space: migration 002. Run after wantiss-vendor-schema.sql (001).
-- All money, verification, status and ownership changes happen in SECURITY DEFINER functions. The client only reads, and edits draft content.

alter table businesses add column if not exists currency text not null default 'USD';
alter table business_features add column if not exists activated_at timestamptz default now();
alter table notifications add column if not exists feature text;
alter table conversations add column if not exists customer_name text, add column if not exists last_body text, add column if not exists unread_business int not null default 0, add column if not exists ref_label text;
alter table promotions add column if not exists discount_text text, add column if not exists redemptions int not null default 0, add column if not exists vendor_cost numeric(12,2) not null default 0;
alter table wallet_ledger add column if not exists label text;
create index if not exists wl_biz_time on wallet_ledger(business_id, created_at desc);

create table if not exists profiles(id uuid primary key references auth.users on delete cascade, full_name text, username text unique);
create table if not exists notification_prefs(user_id uuid primary key references auth.users on delete cascade, push boolean not null default true, email boolean not null default false);
create table if not exists payout_methods(id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, holder text not null, last4 text not null, provider_token text, created_at timestamptz default now());

create table if not exists listings(
  id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, feature text not null,
  title text not null, description text, category text, subcategory text, price numeric(14,2) check (price is null or price >= 0),
  stock int check (stock is null or stock >= 0),                     -- never negative: oversell protection lives in reserve_stock()
  photos text[] not null default '{}', attributes jsonb not null default '{}',
  status text not null default 'draft' check (status in ('draft','in_review','published','paused','archived')),
  idempotency_key text unique, created_by uuid default auth.uid(), created_at timestamptz default now(), updated_at timestamptz default now());
create index if not exists listings_biz on listings(business_id, feature, status);

create table if not exists feature_orders(
  id uuid primary key default gen_random_uuid(), business_id uuid not null references businesses on delete cascade, feature text not null,
  listing_id uuid references listings, customer_id uuid, customer_name text, title text, amount numeric(14,2) not null,
  refunded numeric(14,2) not null default 0 check (refunded <= amount), status text, payment_status text not null default 'paid',
  created_at timestamptz default now(), updated_at timestamptz default now());
create index if not exists fo_biz on feature_orders(business_id, feature, status);

create table if not exists status_transitions(feature text, from_status text, to_status text, primary key(feature, from_status, to_status));
create table if not exists business_activity(id bigserial primary key, business_id uuid not null references businesses on delete cascade, feature text, kind text not null, title text not null, link jsonb, at timestamptz default now());

-- Feature-specific lifecycles. The UI mirrors these in features.ts.
do $$ declare f jsonb := '{
 "goodies":["New","Accepted","Processing","Ready","Completed"],"stayz":["Requested","Accepted","Upcoming","Checked in","Completed"],
 "flyz":["Booked","Ticketed","Confirmed","Completed"],"woulib":["Requested","Driver assigned","En route","In progress","Completed"],
 "rideza":["Reserved","Confirmed","Picked up","Returned","Completed"],"habita":["Inquiry","Viewing scheduled","Offer","Under contract","Closed"],
 "services":["Requested","Accepted","Scheduled","In progress","Completed"],"arts":["New","Accepted","In production","Shipped","Completed"],
 "gatherz":["Booked","Confirmed","Checked in","Completed"],"glowz":["Requested","Confirmed","In service","Completed"],
 "streamz":["Pending","Active","Completed"],"dealz":["Claimed","Redeemed","Settled"],"prezo":["New","Accepted","Wrapped","Shipped","Completed"],
 "globiz":["Inquiry","Quoted","Accepted","Completed"],"bidz":["Live","Ended","Awarded","Paid","Completed"],"lutz":["Open","Sold out","Drawn","Prize sent","Completed"],
 "konsoliss":["Booked","Received at warehouse","Consolidated","In transit","Delivered"],"frenzies":["Entered","Confirmed","Played","Settled"]}';
 k text; a jsonb; i int;
begin
  for k, a in select * from jsonb_each(f) loop
    for i in 0..jsonb_array_length(a)-2 loop
      insert into status_transitions values (k, a->>i, a->>(i+1)) on conflict do nothing;
    end loop;
  end loop;
end $$;

create or replace function first_status(f text) returns text language sql stable as
$$ select from_status from status_transitions t where feature=f and not exists(select 1 from status_transitions x where x.feature=f and x.to_status=t.from_status) limit 1 $$;
create or replace function is_terminal(f text, s text) returns boolean language sql stable as
$$ select not exists(select 1 from status_transitions where feature=f and from_status=s) $$;
create or replace function is_admin() returns boolean language sql stable as $$ select coalesce(auth.jwt()->'app_metadata'->>'role','')='admin' $$;

create or replace function trg_touch() returns trigger language plpgsql as $$ begin new.updated_at=now(); return new; end $$;
create trigger listings_touch before update on listings for each row execute function trg_touch();
create trigger orders_touch before update on feature_orders for each row execute function trg_touch();
create or replace function trg_order_first() returns trigger language plpgsql as $$ begin new.status = coalesce(new.status, first_status(new.feature)); return new; end $$;
create trigger orders_first before insert on feature_orders for each row execute function trg_order_first();

create or replace function log_event(b uuid, f text, kind text, title text, link jsonb default null) returns void language sql security definer set search_path=public as $$
  with a as (insert into audit_log(business_id,actor_id,action,meta) values (b,auth.uid(),kind,jsonb_build_object('title',title,'feature',f)) returning 1)
  insert into business_activity(business_id,feature,kind,title,link) values (b,f,kind,title,link) $$;
create or replace function notify(b uuid, f text, k text, t text, link jsonb default null) returns void language sql security definer set search_path=public as $$
  insert into notifications(business_id,user_id,feature,kind,title,link) select b, user_id, f, k, t, link from business_members where business_id=b $$;

-- ===== Business, verification, features =====
create or replace function create_business(p_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare b uuid;
begin
  if auth.uid() is null then raise exception 'sign in first'; end if;
  insert into businesses(name) values (trim(p_name)) returning id into b;
  insert into business_members values (b, auth.uid(), 'owner');
  perform log_event(b, null, 'business_created', 'Business profile created');
  return b;
end $$;

create or replace function submit_verification(p_business uuid, p_documents jsonb) returns void language plpgsql security definer set search_path=public as $$
begin
  if not exists(select 1 from business_members where business_id=p_business and user_id=auth.uid() and role='owner') then raise exception 'only the owner can submit verification'; end if;
  update businesses set verification='pending' where id=p_business and verification in ('setup','action');
  if not found then raise exception 'verification cannot be submitted in the current state'; end if;
  insert into verification_requests(business_id, documents) values (p_business, p_documents);
  perform log_event(p_business, null, 'verification_submitted', 'Verification submitted for review');
end $$;

create or replace function admin_decide_verification(p_business uuid, p_decision text) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_admin() then raise exception 'admins only'; end if;
  if p_decision not in ('verified','action','restricted') then raise exception 'bad decision'; end if;
  update businesses set verification=p_decision::verification_status where id=p_business;
  update verification_requests set decision=p_decision, decided_by=auth.uid(), decided_at=now() where business_id=p_business and decision is null;
  perform notify(p_business, null, 'verification', 'Verification update: '||p_decision, '{"view":"onboard"}');
  perform log_event(p_business, null, 'verification_decided', 'Verification: '||p_decision);
end $$;

create or replace function save_payout_method(p_business uuid, p_holder text, p_account text, p_token text default null) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  insert into payout_methods(business_id,holder,last4,provider_token) values (p_business, p_holder, right(regexp_replace(p_account,'\s','','g'),4), p_token);
  update businesses set payout_ready=true where id=p_business;
  perform log_event(p_business, null, 'payout_method_added', 'Payout method added');
end $$;

create or replace function activate_feature(p_business uuid, p_feature text) returns void language plpgsql security definer set search_path=public as $$
declare v verification_status;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  if p_feature='topup' or not exists(select 1 from status_transitions where feature=p_feature) then raise exception 'this feature has no vendor tools'; end if;
  select verification into v from businesses where id=p_business;
  if v='restricted' then raise exception 'business is restricted'; end if;
  insert into business_features(business_id, feature, status) values (p_business, p_feature, case when v='verified' and p_feature not in ('lutz','frenzies') then 'active' else 'setup' end) on conflict do nothing;
  perform log_event(p_business, p_feature, 'feature_activated', 'Feature activated: '||p_feature);
end $$;

create or replace function deactivate_feature(p_business uuid, p_feature text) returns void language plpgsql security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  if exists(select 1 from feature_orders o where business_id=p_business and feature=p_feature and not is_terminal(feature,status)) then raise exception 'resolve open orders and bookings first'; end if;
  update listings set status='paused' where business_id=p_business and feature=p_feature and status='published';
  delete from business_features where business_id=p_business and feature=p_feature;
  perform log_event(p_business, p_feature, 'feature_deactivated', 'Feature deactivated: '||p_feature);
end $$;

create or replace function go_live(p_business uuid) returns void language plpgsql security definer set search_path=public as $$
declare b businesses;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select * into b from businesses where id=p_business;
  if b.verification<>'verified' then raise exception 'verification is not complete'; end if;
  if not b.payout_ready then raise exception 'set up payouts first'; end if;
  if not exists(select 1 from business_features where business_id=p_business) then raise exception 'activate a feature first'; end if;
  if not exists(select 1 from listings where business_id=p_business) then raise exception 'add a listing first'; end if;
  update businesses set is_live=true where id=p_business;
  perform log_event(p_business, null, 'went_live', 'Business went live');
end $$;

-- ===== Listings =====
-- Draft creation is idempotent: a retry with the same key returns the same draft instead of a duplicate.
create or replace function create_draft(p_business uuid, p_feature text, p_key text, p_title text) returns uuid language plpgsql security definer set search_path=public as $$
declare id uuid;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select l.id into id from listings l where idempotency_key=p_key; if found then return id; end if;
  if not exists(select 1 from business_features where business_id=p_business and feature=p_feature) then raise exception 'activate % first', p_feature; end if;
  insert into listings(business_id,feature,title,idempotency_key) values (p_business,p_feature,coalesce(nullif(trim(p_title),''),'Untitled draft'),p_key) returning listings.id into id;
  perform log_event(p_business, p_feature, 'listing_draft', 'Draft created in '||p_feature, jsonb_build_object('view','feat','arg',p_feature));
  return id;
end $$;

create or replace function publish_listing(p_listing uuid) returns text language plpgsql security definer set search_path=public as $$
declare l listings; b businesses; s text;
begin
  select * into l from listings where id=p_listing;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  select * into b from businesses where id=l.business_id;
  if b.verification<>'verified' then raise exception 'your business must be verified before publishing'; end if;
  if not exists(select 1 from business_features where business_id=l.business_id and feature=l.feature) then raise exception 'activate % first', l.feature; end if;
  if coalesce(trim(l.title),'')='' then raise exception 'title is required'; end if;
  if l.feature<>'flyz' and coalesce(array_length(l.photos,1),0)<1 then raise exception 'add at least one photo'; end if;
  if l.feature in ('goodies','dealz','prezo','arts','bidz') and coalesce(l.price, (l.attributes->>'start')::numeric, 0) <= 0 then raise exception 'set a price'; end if;
  s := case when l.feature in ('lutz','frenzies') then 'in_review' else 'published' end;
  update listings set status=s where id=p_listing;
  perform log_event(l.business_id, l.feature, 'listing_'||s, l.title, jsonb_build_object('view','feat','arg',l.feature));
  return s;
end $$;

create or replace function set_listing_status(p_listing uuid, p_status text) returns void language plpgsql security definer set search_path=public as $$
declare l listings;
begin
  select * into l from listings where id=p_listing;
  if not found or not is_member(l.business_id) then raise exception 'not allowed'; end if;
  if not ((l.status='published' and p_status in ('paused','archived')) or (l.status='paused' and p_status in ('published','archived')) or (l.status='draft' and p_status='archived')) then raise exception 'invalid change'; end if;
  update listings set status=p_status where id=p_listing;
  perform log_event(l.business_id, l.feature, 'listing_'||p_status, l.title);
end $$;

-- Atomic stock reservation for checkout. Two buyers cannot oversell the same item.
create or replace function reserve_stock(p_listing uuid, p_qty int) returns boolean language plpgsql security definer set search_path=public as $$
begin
  update listings set stock = stock - p_qty where id=p_listing and status='published' and stock is not null and stock >= p_qty;
  return found;
end $$;

-- ===== Orders and money =====
create or replace function advance_order(p_order uuid) returns text language plpgsql security definer set search_path=public as $$
declare o feature_orders; nxt text;
begin
  select * into o from feature_orders where id=p_order for update;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  select to_status into nxt from status_transitions where feature=o.feature and from_status=o.status limit 1;
  if nxt is null then raise exception 'this order is already complete'; end if;
  update feature_orders set status=nxt where id=p_order;
  perform log_event(o.business_id, o.feature, 'order_status', coalesce(o.title,'Order')||' moved to '||nxt, jsonb_build_object('view','feat','arg',o.feature));
  return nxt;
end $$;

create or replace function refund_order(p_order uuid, p_amount numeric, p_key text) returns uuid language plpgsql security definer set search_path=public as $$
declare o feature_orders; rid uuid; fee numeric;
begin
  select id into rid from wallet_ledger where idempotency_key=p_key; if found then return rid; end if;
  select * into o from feature_orders where id=p_order for update;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  if p_amount <= 0 or p_amount > o.amount - o.refunded then raise exception 'refund exceeds the refundable amount'; end if;
  if o.status = first_status(o.feature) then raise exception 'cancel or accept the order before refunding'; end if;
  insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,idempotency_key,label) values (o.business_id,o.feature,'refund','posted',-p_amount,'feature_orders',o.id,p_key,'Refund · '||coalesce(o.title,'order')) returning id into rid;
  fee := round(p_amount*0.06,2);   -- platform fee is returned proportionally
  insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,label) values (o.business_id,o.feature,'fee','posted',fee,'feature_orders',o.id,'Platform fee reversal');
  update feature_orders set refunded=refunded+p_amount where id=p_order;
  perform log_event(o.business_id, o.feature, 'refund', 'Refunded '||p_amount||' on '||coalesce(o.title,'order'));
  return rid;
end $$;

create or replace function request_payout(b uuid, amt numeric, key text) returns uuid language plpgsql security definer set search_path=public as $$
declare avail numeric; rid uuid;
begin
  if not is_member(b) then raise exception 'not allowed'; end if;
  select id into rid from wallet_ledger where idempotency_key=key; if found then return rid; end if;
  if not (select payout_ready and verification='verified' from businesses where id=b) then raise exception 'payouts are not available yet'; end if;
  select coalesce(available,0) into avail from wallet_balance where business_id=b;
  if amt<=0 or amt>avail then raise exception 'amount exceeds your available balance'; end if;
  insert into wallet_ledger(business_id,type,status,amount,idempotency_key,label) values (b,'payout','processing',-amt,key,'Payout') returning id into rid;
  perform log_event(b, null, 'payout_requested', 'Payout requested: '||amt);
  perform notify(b, null, 'payout', 'Payout of '||amt||' is processing', '{"view":"wallet"}');
  return rid;
end $$;

-- ===== Read models (computed in the database, never in the client) =====
create or replace function dashboard_summary(p_business uuid, p_days int, p_feature text default null) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare cur numeric; prv numeric; av numeric; pe numeric; ser jsonb; mix jsonb; n int := case when p_days=7 then 7 else 10 end;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select coalesce(sum(amount),0) into cur from wallet_ledger where business_id=p_business and type<>'payout' and created_at >= now()-make_interval(days=>p_days) and (p_feature is null or feature=p_feature);
  select coalesce(sum(amount),0) into prv from wallet_ledger where business_id=p_business and type<>'payout' and created_at >= now()-make_interval(days=>2*p_days) and created_at < now()-make_interval(days=>p_days) and (p_feature is null or feature=p_feature);
  select coalesce(available,0), coalesce(pending,0) into av, pe from wallet_balance where business_id=p_business;
  select coalesce(jsonb_agg(coalesce(v,0) order by i),'[]') into ser from (
    select g.i, (select sum(amount) from wallet_ledger l where l.business_id=p_business and l.type<>'payout' and (p_feature is null or l.feature=p_feature)
      and l.created_at >= now()-make_interval(secs=>p_days*86400.0*(n-g.i)/n) and l.created_at < now()-make_interval(secs=>p_days*86400.0*(n-1-g.i)/n)) v
    from generate_series(0,n-1) g(i)) s;
  select coalesce(jsonb_agg(jsonb_build_object('feature',feature,'amount',a) order by a desc),'[]') into mix from (
    select feature, sum(amount) a from wallet_ledger where business_id=p_business and type='sale' and feature is not null and created_at >= now()-make_interval(days=>p_days) group by feature) x;
  return jsonb_build_object('revenue',cur,'prev',prv,'available',coalesce(av,0),'pending',coalesce(pe,0),'series',ser,'mix',mix);
end $$;

create or replace function earnings_breakdown(p_business uuid, p_days int) returns jsonb language sql stable security definer set search_path=public as $$
  select case when not is_member(p_business) then null else jsonb_build_object(
    'gross', coalesce(sum(amount) filter (where type='sale'),0), 'fees', coalesce(sum(amount) filter (where type='fee'),0),
    'refunds', coalesce(sum(amount) filter (where type='refund'),0), 'payouts', coalesce(sum(amount) filter (where type='payout'),0),
    'pending_count', count(*) filter (where type='sale' and status='pending')) end
  from wallet_ledger where business_id=p_business and created_at >= now()-make_interval(days=>p_days) $$;

create or replace function action_required(p_business uuid) returns table(kind text, feature text, label text, sub text, target text) language plpgsql stable security definer set search_path=public as $$
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query select 'orders', o.feature, 'Review '||count(*)||' new request'||case when count(*)>1 then 's' else '' end, o.feature, 'feature:'||o.feature
    from feature_orders o where o.business_id=p_business and o.status=first_status(o.feature) group by o.feature;
  return query select 'stock', l.feature, count(*)||' item'||case when count(*)>1 then 's' else '' end||' low on stock', l.feature, 'feature:'||l.feature
    from listings l where l.business_id=p_business and l.status='published' and l.stock is not null and l.stock <= coalesce((l.attributes->>'low')::int,3) group by l.feature;
  return query select 'verification', null::text, 'Complete business verification', 'Verification', 'onboard' from businesses where id=p_business and verification<>'verified';
  return query select 'payout', null::text, 'Add payout method', 'Payments', 'payout' from businesses where id=p_business and not payout_ready;
  return query select 'messages', null::text, 'Reply to '||sum(unread_business)||' messages', 'Messages', 'messages' from conversations where business_id=p_business having coalesce(sum(unread_business),0)>0;
end $$;

create or replace function search_business(p_business uuid, p_q text) returns table(scope text, title text, sub text, feature text, target text) language plpgsql stable security definer set search_path=public as $$
declare q text := '%'||replace(replace(p_q,'%','\%'),'_','\_')||'%';
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  return query select 'Listings', l.title, 'Listing · '||l.status, l.feature, 'listing:'||l.id from listings l where l.business_id=p_business and l.title ilike q limit 8;
  return query select 'Orders', coalesce(o.title,'Order'), 'Order · '||o.status, o.feature, 'feature:'||o.feature from feature_orders o where o.business_id=p_business and (o.title ilike q or o.id::text ilike q) limit 8;
  return query select 'Customers', o.customer_name, 'Customer', o.feature, 'feature:'||o.feature from feature_orders o where o.business_id=p_business and o.customer_name ilike q limit 5;
  return query select 'Promotions', p.title, 'Promotion · '||p.status, p.feature, 'promo' from promotions p where p.business_id=p_business and p.title ilike q limit 5;
  return query select 'Money', coalesce(w.label,w.type::text), 'Transaction · '||w.status, coalesce(w.feature,'goodies'), 'wallet' from wallet_ledger w where w.business_id=p_business and (w.label ilike q or w.type::text ilike q) order by w.created_at desc limit 5;
end $$;

create or replace function mark_notifications_read(p_business uuid) returns void language sql security definer set search_path=public as $$
  update notifications set read_at=now() where business_id=p_business and read_at is null and is_member(p_business) $$;
create or replace function mark_conversation_read(p_conv uuid) returns void language sql security definer set search_path=public as $$
  update conversations set unread_business=0 where id=p_conv and is_member(business_id) $$;
create or replace function set_promotion_status(p_id uuid, p_status text) returns void language plpgsql security definer set search_path=public as $$
declare p promotions;
begin
  select * into p from promotions where id=p_id;
  if not found or not is_member(p.business_id) or p.funded_by<>'vendor' then raise exception 'not allowed'; end if;
  if not ((p.status='active' and p_status in ('paused','ended')) or (p.status='paused' and p_status in ('active','ended'))) then raise exception 'invalid change'; end if;
  update promotions set status=p_status where id=p_id;
  perform log_event(p.business_id, p.feature, 'promotion_'||p_status, p.title);
end $$;

create or replace function trg_message() returns trigger language plpgsql security definer set search_path=public as $$
begin
  update conversations set last_body=new.body, unread_business = unread_business + case when exists(select 1 from business_members m where m.business_id=conversations.business_id and m.user_id=new.sender_id) then 0 else 1 end where id=new.conversation_id;
  return new;
end $$;
create trigger messages_after after insert on messages for each row execute function trg_message();

-- ===== RLS =====
alter table listings enable row level security; alter table feature_orders enable row level security; alter table business_activity enable row level security;
alter table profiles enable row level security; alter table notification_prefs enable row level security; alter table payout_methods enable row level security;
alter table status_transitions enable row level security; alter table verification_requests enable row level security;

create policy "read transitions" on status_transitions for select using (true);
create policy "members read listings" on listings for select using (is_member(business_id));
create policy "members edit listings" on listings for update using (is_member(business_id)) with check (is_member(business_id));
revoke update on listings from authenticated;      -- status, business and feature can only change through RPCs
grant update(title, description, category, subcategory, price, stock, photos, attributes) on listings to authenticated;
create policy "members read orders" on feature_orders for select using (is_member(business_id));
create policy "members read activity" on business_activity for select using (is_member(business_id));
create policy "own profile" on profiles for all using (id=auth.uid()) with check (id=auth.uid());
create policy "own prefs" on notification_prefs for all using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy "members read payout methods" on payout_methods for select using (is_member(business_id));
create policy "members read verification" on verification_requests for select using (is_member(business_id));
create policy "members create promotions" on promotions for insert with check (is_member(business_id) and funded_by='vendor' and status='in_review');
create policy "members send messages" on messages for insert with check (sender_id=auth.uid() and exists(select 1 from conversations c where c.id=conversation_id and is_member(c.business_id)));
create policy "members update notifications" on notifications for update using (is_member(business_id));

revoke insert, update, delete on wallet_ledger, feature_orders, business_features, businesses, business_members from authenticated;
grant update(name, logo_url) on businesses to authenticated;

-- ===== Storage =====
insert into storage.buckets(id,name,public) values ('listing-photos','listing-photos',true),('business-docs','business-docs',false),('creator-media','creator-media',false) on conflict do nothing;
create policy "public read listing photos" on storage.objects for select using (bucket_id='listing-photos');
create policy "members read private files" on storage.objects for select using (bucket_id in ('business-docs','creator-media') and is_member(((storage.foldername(name))[1])::uuid));
create policy "members upload files" on storage.objects for insert with check (bucket_id in ('listing-photos','business-docs','creator-media') and is_member(((storage.foldername(name))[1])::uuid));
create policy "members delete files" on storage.objects for delete using (bucket_id in ('listing-photos','business-docs','creator-media') and is_member(((storage.foldername(name))[1])::uuid));

alter publication supabase_realtime add table wallet_ledger, feature_orders, notifications, business_activity, messages, listings;

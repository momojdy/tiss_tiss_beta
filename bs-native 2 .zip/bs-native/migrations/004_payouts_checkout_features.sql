-- Migration 004. Run after 001, 002 and 003 (in that order) on a clean staging project first.
-- Payout state machine and reconciliation, fully protected ledger, atomic checkout / cancellation / reservation release,
-- and a detail table with real constraints for every remaining feature.

create or replace function is_owner(b uuid) returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from business_members where business_id=b and user_id=auth.uid() and role='owner') $$;

-- ===== 1. Payout lifecycle =====
-- ledger payout row:  processing  = requested, money not yet confirmed at the bank
--                     completed   = provider confirmed the bank payout (payout.paid)
--                     failed      = never completed; funds return to the available balance automatically
-- If a payout fails AFTER it was marked completed, history is not rewritten: a new 'adjustment' event restores the funds.
create table if not exists payout_transfers(ledger_id uuid primary key references wallet_ledger, provider_transfer_id text unique,
  state text not null default 'transferred' check (state in ('transferred','paid','failed','reversed')), updated_at timestamptz not null default now());
create table if not exists webhook_events(id text primary key, received_at timestamptz not null default now());   -- duplicate delivery guard
alter table payout_transfers enable row level security; alter table webhook_events enable row level security;

create or replace function record_transfer(p_ledger uuid, p_transfer text) returns void language sql security definer set search_path=public as
$$ insert into payout_transfers(ledger_id, provider_transfer_id) values (p_ledger, p_transfer) on conflict (ledger_id) do nothing $$;

create or replace function settle_payout(p_ledger uuid, p_status text) returns void language plpgsql security definer set search_path=public as $$
declare w wallet_ledger;
begin
  if p_status not in ('completed','failed') then raise exception 'bad status'; end if;
  select * into w from wallet_ledger where id=p_ledger and type='payout' for update;
  if not found then return; end if;
  if p_status='completed' then
    if w.status<>'processing' then return; end if;                           -- idempotent: duplicate webhooks do nothing
    update wallet_ledger set status='completed' where id=p_ledger;
    update payout_transfers set state='paid', updated_at=now() where ledger_id=p_ledger;
    perform notify(w.business_id, null, 'payout', 'Payout completed', '{"view":"wallet"}');
  elsif w.status='processing' then
    update wallet_ledger set status='failed' where id=p_ledger;
    update payout_transfers set state='failed', updated_at=now() where ledger_id=p_ledger;
    perform notify(w.business_id, null, 'payout', 'Payout failed. The funds are back in your balance.', '{"view":"wallet"}');
  elsif w.status='completed' then
    insert into wallet_ledger(business_id,type,status,amount,ref_table,ref_id,idempotency_key,label)
      values (w.business_id,'adjustment','posted',-w.amount,'wallet_ledger',w.id,'payout-reversal-'||w.id,'Payout reversal') on conflict (idempotency_key) do nothing;
    update payout_transfers set state='reversed', updated_at=now() where ledger_id=p_ledger;
    perform notify(w.business_id, null, 'payout', 'A completed payout was reversed by the bank', '{"view":"wallet"}');
  end if;
  perform log_event(w.business_id, null, 'payout_'||p_status, 'Payout '||p_status);
end $$;

-- ===== 3. Ledger: every column except status is frozen; status moves only along allowed paths; nothing is deleted =====
create or replace function trg_ledger_guard() returns trigger language plpgsql as $$
begin
  if tg_op='DELETE' then raise exception 'ledger entries cannot be deleted'; end if;
  if (to_jsonb(new) - 'status') is distinct from (to_jsonb(old) - 'status') then raise exception 'ledger entries are immutable'; end if;
  if new.status<>old.status and not ((old.status='pending' and new.status in ('posted','failed','reversed')) or (old.status='processing' and new.status in ('completed','failed')) or (old.status='posted' and new.status='reversed')) then
    raise exception 'invalid ledger status change % -> %', old.status, new.status; end if;
  return new;
end $$;

-- Revenue means sales, fees and refunds only. Payout reversals and payouts are money movements, not revenue.
create or replace function dashboard_summary(p_business uuid, p_days int, p_feature text default null) returns jsonb language plpgsql stable security definer set search_path=public as $$
declare cur numeric; prv numeric; av numeric; pe numeric; ser jsonb; mix jsonb; n int := case when p_days=7 then 7 else 10 end;
begin
  if not is_member(p_business) then raise exception 'not allowed'; end if;
  select coalesce(sum(amount),0) into cur from wallet_ledger where business_id=p_business and type in ('sale','fee','refund') and status not in ('reversed','failed') and created_at >= now()-make_interval(days=>p_days) and (p_feature is null or feature=p_feature);
  select coalesce(sum(amount),0) into prv from wallet_ledger where business_id=p_business and type in ('sale','fee','refund') and status not in ('reversed','failed') and created_at >= now()-make_interval(days=>2*p_days) and created_at < now()-make_interval(days=>p_days) and (p_feature is null or feature=p_feature);
  select coalesce(available,0), coalesce(pending,0) into av, pe from wallet_balance where business_id=p_business;
  select coalesce(jsonb_agg(coalesce(v,0) order by i),'[]') into ser from (
    select g.i, (select sum(amount) from wallet_ledger l where l.business_id=p_business and l.type in ('sale','fee','refund') and l.status not in ('reversed','failed') and (p_feature is null or l.feature=p_feature)
      and l.created_at >= now()-make_interval(secs=>p_days*86400.0*(n-g.i)/n) and l.created_at < now()-make_interval(secs=>p_days*86400.0*(n-1-g.i)/n)) v
    from generate_series(0,n-1) g(i)) s;
  select coalesce(jsonb_agg(jsonb_build_object('feature',feature,'amount',a) order by a desc),'[]') into mix from (
    select feature, sum(amount) a from wallet_ledger where business_id=p_business and type='sale' and status not in ('reversed','failed') and feature is not null and created_at >= now()-make_interval(days=>p_days) group by feature) x;
  return jsonb_build_object('revenue',cur,'prev',prv,'available',coalesce(av,0),'pending',coalesce(pe,0),'series',ser,'mix',mix);
end $$;

-- ===== 4. Order lifecycle: cancel branch, funds release on completion, refunds share one routine =====
alter table status_transitions add column if not exists kind text not null default 'forward' check (kind in ('forward','cancel'));
insert into status_transitions(feature, from_status, to_status, kind)
  select t.feature, t.from_status, 'Cancelled', 'cancel' from status_transitions t
  where t.kind='forward' and (t.from_status = first_status(t.feature) or t.from_status = (select x.to_status from status_transitions x where x.feature=t.feature and x.from_status=first_status(t.feature) and x.kind='forward' limit 1))
  on conflict do nothing;
create or replace function first_status(f text) returns text language sql stable as
$$ select from_status from status_transitions t where feature=f and kind='forward' and not exists(select 1 from status_transitions x where x.feature=f and x.kind='forward' and x.to_status=t.from_status) limit 1 $$;

alter table feature_orders add column if not exists qty int not null default 1 check (qty>0), add column if not exists variant_id uuid references listing_variants, add column if not exists idempotency_key text unique;

create or replace function advance_order(p_order uuid) returns text language plpgsql security definer set search_path=public as $$
declare o feature_orders; nxt text;
begin
  select * into o from feature_orders where id=p_order for update;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  select to_status into nxt from status_transitions where feature=o.feature and from_status=o.status and kind='forward' limit 1;
  if nxt is null then raise exception 'this order is already closed'; end if;
  update feature_orders set status=nxt where id=p_order;
  perform log_event(o.business_id, o.feature, 'order_status', coalesce(o.title,'Order')||' moved to '||nxt, jsonb_build_object('view','feat','arg',o.feature));
  return nxt;
end $$;

-- Pending sale and fee entries become available when the order reaches its final status (settlement).
create or replace function trg_release_funds() returns trigger language plpgsql as $$
begin
  if new.status is distinct from old.status and new.status<>'Cancelled' and is_terminal(new.feature,new.status) then
    update wallet_ledger set status='posted' where ref_table='feature_orders' and ref_id=new.id and status='pending' and type in ('sale','fee');
  end if;
  return new;
end $$;
drop trigger if exists orders_release on feature_orders;
create trigger orders_release after update of status on feature_orders for each row execute function trg_release_funds();

create table if not exists fee_rules(feature text primary key, rate numeric(5,4) not null check (rate>=0 and rate<=0.5));
insert into fee_rules select distinct feature, 0.06 from status_transitions on conflict do nothing;
alter table fee_rules enable row level security;
create or replace function fee_rate(f text) returns numeric language sql stable as $$ select coalesce((select rate from fee_rules where feature=f), 0.06) $$;

create or replace function ledger_refund(o feature_orders, p_amount numeric, p_key text) returns uuid language plpgsql security definer set search_path=public as $$
declare rid uuid; sold numeric; fee_paid numeric; fee numeric;
begin
  if p_amount <= 0 or p_amount > o.amount - o.refunded then raise exception 'refund exceeds the refundable amount'; end if;
  select coalesce(sum(amount) filter (where type='sale'),0), coalesce(-sum(amount) filter (where type='fee' and amount<0),0) into sold, fee_paid from wallet_ledger where ref_table='feature_orders' and ref_id=o.id;
  fee := case when sold>0 then round(p_amount * fee_paid / sold, 2) else 0 end;
  insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,idempotency_key,label) values (o.business_id,o.feature,'refund','posted',-p_amount,'feature_orders',o.id,p_key,'Refund · '||coalesce(o.title,'order')) returning id into rid;
  if fee > 0 then insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,idempotency_key,label) values (o.business_id,o.feature,'fee','posted',fee,'feature_orders',o.id,p_key||'-fee','Platform fee reversal'); end if;
  update feature_orders set refunded=refunded+p_amount where id=o.id;
  return rid;
end $$;

create or replace function refund_order(p_order uuid, p_amount numeric, p_key text) returns uuid language plpgsql security definer set search_path=public as $$
declare o feature_orders; rid uuid;
begin
  select id into rid from wallet_ledger where idempotency_key=p_key; if found then return rid; end if;
  select * into o from feature_orders where id=p_order;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  perform 1 from businesses where id=o.business_id for update;
  select * into o from feature_orders where id=p_order for update;
  if o.status='Cancelled' then raise exception 'this order was cancelled'; end if;
  if o.status = first_status(o.feature) then raise exception 'accept or cancel the order before refunding'; end if;
  rid := ledger_refund(o, p_amount, p_key);
  perform log_event(o.business_id, o.feature, 'refund', 'Refunded '||p_amount||' on '||coalesce(o.title,'order'));
  return rid;
end $$;

-- Cancel: releases every reservation and returns the customer's money.
create or replace function cancel_order(p_order uuid, p_reason text) returns void language plpgsql security definer set search_path=public as $$
declare o feature_orders;
begin
  select * into o from feature_orders where id=p_order;
  if not found or not is_member(o.business_id) then raise exception 'not allowed'; end if;
  perform 1 from businesses where id=o.business_id for update;
  select * into o from feature_orders where id=p_order for update;
  if not exists(select 1 from status_transitions where feature=o.feature and from_status=o.status and kind='cancel') then raise exception 'this order can no longer be cancelled'; end if;
  update feature_orders set status='Cancelled' where id=p_order;
  if exists(select 1 from wallet_ledger where ref_table='feature_orders' and ref_id=o.id and status='pending') then
    update wallet_ledger set status='reversed' where ref_table='feature_orders' and ref_id=o.id and status='pending' and type in ('sale','fee');   -- funds were never released
  elsif o.amount - o.refunded > 0 then
    perform ledger_refund(o, o.amount - o.refunded, 'cancel-'||o.id);
  end if;
  update listings set stock=stock+o.qty where id=o.listing_id and stock is not null;
  update listing_variants set stock=stock+o.qty where id=o.variant_id and stock is not null;
  update stayz_bookings set active=false where order_id=p_order;
  update rideza_reservations set active=false where order_id=p_order;
  update habita_inquiries set active=false where order_id=p_order;
  update services_requests set active=false where order_id=p_order;
  update streamz_access set active=false where order_id=p_order;
  delete from lutz_ticket_numbers where order_id=p_order;
  delete from frenzies_entries where order_id=p_order;
  update arts_orders set edition_no=null where order_id=p_order;
  perform log_event(o.business_id, o.feature, 'order_cancelled', coalesce(o.title,'Order')||' cancelled: '||coalesce(nullif(p_reason,''),'no reason given'), jsonb_build_object('view','feat','arg',o.feature));
end $$;

-- ===== 5. Detail tables with real constraints for every remaining feature =====
alter table stayz_bookings alter column active set default true;
create table if not exists flyz_bookings(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings,
  passengers int not null check (passengers between 1 and 9), passenger_names jsonb not null default '[]', ticket_no text unique);
create table if not exists habita_inquiries(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings,
  kind text not null check (kind in ('inquiry','viewing','offer')), slot tstzrange, offer_amount numeric(14,2), message text, active boolean not null default true,
  constraint no_double_viewing exclude using gist (listing_id with =, slot with &&) where (active and slot is not null));
create table if not exists services_requests(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings,
  slot tstzrange not null, address text, active boolean not null default true,
  constraint no_double_service exclude using gist (listing_id with =, slot with &&) where (active));
create table if not exists glowz_appointments(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, slot tstzrange not null, addons jsonb not null default '[]');
create table if not exists gatherz_tickets(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, tier text not null, qty int not null check (qty>0));
create table if not exists arts_orders(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, ship_to jsonb, edition_no int, unique (listing_id, edition_no));
create table if not exists streamz_access(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, user_id uuid not null, plan text not null, period tstzrange, active boolean not null default true,
  constraint one_active_access exclude using gist (listing_id with =, user_id with =) where (active));
create table if not exists dealz_claims(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, user_id uuid not null, code text not null unique, redeemed_at timestamptz);
create table if not exists prezo_orders(order_id uuid primary key references feature_orders on delete cascade, recipient jsonb not null, message text, deliver_on date, gift_wrap boolean not null default false, anonymous boolean not null default false);
create table if not exists globiz_inquiries(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, message text, quote numeric(14,2));
create table if not exists lutz_ticket_numbers(listing_id uuid not null references listings, n int not null check (n>0), order_id uuid not null references feature_orders on delete cascade, primary key (listing_id, n));
create table if not exists raffle_draws(listing_id uuid primary key references listings, winning_n int not null, order_id uuid references feature_orders, drawn_at timestamptz not null default now());
create table if not exists frenzies_entries(order_id uuid primary key references feature_orders on delete cascade, listing_id uuid not null references listings, player uuid not null, rank int, prize numeric(12,2), unique (listing_id, player));
create table if not exists bidz_bids(id bigserial primary key, listing_id uuid not null references listings, bidder uuid not null, amount numeric(14,2) not null check (amount>0), at timestamptz not null default now());
create index if not exists bids_top on bidz_bids(listing_id, amount desc);
create table if not exists bidz_state(listing_id uuid primary key references listings, ends_at timestamptz not null);
alter table konsoliss_shipments add column if not exists created_at timestamptz default now();

create or replace function trg_capacity() returns trigger language plpgsql as $$
declare cap numeric; used numeric;
begin
  select (attributes->>'cbm')::numeric into cap from listings where id=new.route_id for update;
  select coalesce(sum(s.cbm),0) into used from konsoliss_shipments s join feature_orders o on o.id=s.order_id where s.route_id=new.route_id and o.status<>'Cancelled';
  if used + new.cbm > cap then raise exception 'not enough space left on this route'; end if;
  return new;
end $$;

do $$ declare t text;
begin
  foreach t in array array['stayz_bookings','rideza_reservations','woulib_trips','konsoliss_shipments','flyz_bookings','habita_inquiries','services_requests','glowz_appointments','gatherz_tickets','arts_orders','streamz_access','dealz_claims','prezo_orders','globiz_inquiries','lutz_ticket_numbers','frenzies_entries'] loop
    execute format('alter table %I enable row level security', t);
    execute format('drop policy if exists "members read" on %I', t);
    execute format('create policy "members read" on %I for select using (exists(select 1 from feature_orders o where o.id=%I.order_id and is_member(o.business_id)))', t, t);
  end loop;
end $$;
alter table raffle_draws enable row level security; alter table bidz_bids enable row level security; alter table bidz_state enable row level security;
create policy "members read draws" on raffle_draws for select using (exists(select 1 from listings l where l.id=listing_id and is_member(l.business_id)));
create policy "members read bids" on bidz_bids for select using (exists(select 1 from listings l where l.id=listing_id and is_member(l.business_id)));

-- ===== Atomic checkout: order + feature record + reservations + ledger entries in ONE transaction =====
-- Called only by your trusted checkout server (service role) after the payment is authorised.
-- p_key should be the payment intent id, so a retried request returns the same order and never double-charges or double-books.
create or replace function place_order(p_listing uuid, p_customer uuid, p_customer_name text, p_qty int, p_variant uuid, p_details jsonb, p_key text) returns uuid language plpgsql security definer set search_path=public as $$
declare l listings; a jsonb; d jsonb := coalesce(p_details,'{}'); oid uuid; amt numeric; unit numeric; k int; sold int; tier jsonb; fee numeric; ed int; has_var boolean;
begin
  if p_key is null or p_customer is null or p_qty is null or p_qty <= 0 then raise exception 'invalid order'; end if;
  select id into oid from feature_orders where idempotency_key=p_key; if found then return oid; end if;
  select * into l from listings where id=p_listing for update;
  if not found or l.status<>'published' then raise exception 'this listing is not available'; end if;
  if exists(select 1 from business_members where business_id=l.business_id and user_id=p_customer) then raise exception 'you cannot buy from your own business'; end if;
  a := l.attributes; unit := coalesce(l.price,0);
  select exists(select 1 from listing_variants where listing_id=l.id) into has_var;
  if has_var and p_variant is null then raise exception 'choose a variant'; end if;
  if p_variant is not null then
    select coalesce(v.price, unit) into unit from listing_variants v where v.id=p_variant and v.listing_id=l.id;
    if not found then raise exception 'unknown variant'; end if;
  end if;
  amt := unit * p_qty;

  case l.feature
    when 'stayz' then
      k := (d->>'check_out')::date - (d->>'check_in')::date;
      if k < greatest(1, coalesce((a->>'minNights')::int,1)) then raise exception 'the stay is shorter than the minimum'; end if;
      if (d->>'guests')::int > coalesce((a->>'guests')::int, 1) then raise exception 'too many guests'; end if;
      amt := unit*k + coalesce((a->>'cleaning')::numeric,0); p_qty := 1;
    when 'rideza' then
      k := (d->>'to')::date - (d->>'from')::date;
      if k < greatest(1, coalesce((a->>'minDays')::int,1)) then raise exception 'the rental is shorter than the minimum'; end if;
      amt := unit*k; p_qty := 1;
    when 'konsoliss' then
      amt := greatest((d->>'cbm')::numeric * (a->>'perCbm')::numeric, coalesce((a->>'minCharge')::numeric,0)); p_qty := 1;
    when 'woulib' then amt := (d->>'fare')::numeric; p_qty := 1;
    when 'bidz' then amt := (d->>'amount')::numeric; p_qty := 1;
    when 'gatherz' then
      select x into tier from jsonb_array_elements(coalesce(a->'tiers','[]')) x where x->>'name'=d->>'tier' limit 1;
      if tier is null then raise exception 'unknown ticket tier'; end if;
      if p_qty > coalesce((a->>'max')::int, 10) then raise exception 'too many tickets in one order'; end if;
      select coalesce(sum(t.qty),0) into sold from gatherz_tickets t join feature_orders o on o.id=t.order_id where t.listing_id=l.id and t.tier=d->>'tier' and o.status<>'Cancelled';
      if sold + p_qty > (tier->>'qty')::int then raise exception 'not enough tickets left'; end if;
      amt := (tier->>'price')::numeric * p_qty;
    when 'lutz' then
      amt := (a->>'ticket')::numeric * p_qty;
      if p_qty > coalesce((a->>'maxPer')::int, p_qty) then raise exception 'ticket limit per person exceeded'; end if;
    when 'habita','globiz' then amt := 0;
    else null;
  end case;
  if amt is null or amt < 0 then raise exception 'could not price this order'; end if;

  if l.stock is not null or p_variant is not null then
    if not reserve_stock(l.id, p_variant, p_qty) then raise exception 'not enough stock'; end if;
  end if;

  insert into feature_orders(business_id,feature,listing_id,customer_id,customer_name,title,amount,qty,variant_id,idempotency_key)
    values (l.business_id,l.feature,l.id,p_customer,p_customer_name,l.title,amt,p_qty,p_variant,p_key) returning id into oid;

  case l.feature
    when 'stayz' then insert into stayz_bookings(order_id,listing_id,stay,guests) values (oid,l.id,daterange((d->>'check_in')::date,(d->>'check_out')::date,'[)'),(d->>'guests')::int);
    when 'rideza' then insert into rideza_reservations(order_id,listing_id,period) values (oid,l.id,daterange((d->>'from')::date,(d->>'to')::date,'[)'));
    when 'woulib' then insert into woulib_trips(order_id,service_id,pickup,dropoff,distance_km,fare) values (oid,l.id,d->>'pickup',d->>'dropoff',(d->>'distance_km')::numeric,amt);
    when 'konsoliss' then insert into konsoliss_shipments(order_id,route_id,cbm,kg) values (oid,l.id,(d->>'cbm')::numeric,nullif(d->>'kg','')::numeric);
    when 'flyz' then insert into flyz_bookings(order_id,listing_id,passengers,passenger_names) values (oid,l.id,p_qty,coalesce(d->'names','[]'));
    when 'habita' then insert into habita_inquiries(order_id,listing_id,kind,slot,offer_amount,message) values (oid,l.id,coalesce(d->>'kind','inquiry'),
        case when d->>'viewing_at' is not null then tstzrange((d->>'viewing_at')::timestamptz,(d->>'viewing_at')::timestamptz + interval '1 hour') end, nullif(d->>'offer','')::numeric, d->>'message');
    when 'services' then insert into services_requests(order_id,listing_id,slot,address) values (oid,l.id,tstzrange((d->>'start')::timestamptz,(d->>'start')::timestamptz + make_interval(mins=>coalesce((a->>'duration')::int,60))),d->>'address');
    when 'glowz' then
      insert into glowz_appointments(order_id,listing_id,slot,addons) values (oid,l.id,tstzrange((d->>'start')::timestamptz,(d->>'start')::timestamptz + make_interval(mins=>coalesce((a->>'duration')::int,60))),coalesce(d->'addons','[]'));
      select count(*) into k from glowz_appointments g join feature_orders o on o.id=g.order_id where g.listing_id=l.id and o.status<>'Cancelled' and g.slot && (select slot from glowz_appointments where order_id=oid);
      if k > coalesce((a->>'staff')::int,1) then raise exception 'that time is fully booked'; end if;
    when 'gatherz' then insert into gatherz_tickets(order_id,listing_id,tier,qty) values (oid,l.id,d->>'tier',p_qty);
    when 'arts' then
      ed := null;
      if a->>'edition'='Limited edition' then
        if p_qty > 1 then raise exception 'limited editions are one per order'; end if;
        select coalesce(max(edition_no),0)+1 into ed from arts_orders where listing_id=l.id;
        if ed > coalesce((a->>'editionSize')::int,0) then raise exception 'this edition is sold out'; end if;
      end if;
      insert into arts_orders(order_id,listing_id,ship_to,edition_no) values (oid,l.id,d->'ship_to',ed);
    when 'streamz' then insert into streamz_access(order_id,listing_id,user_id,plan,period) values (oid,l.id,p_customer,coalesce(a->>'model','Pay per view'),
        case when a->>'model'='Subscription' then tstzrange(now(), now() + case when a->>'period'='Year' then interval '1 year' else interval '1 month' end) end);
    when 'dealz' then
      select coalesce(sum(o.qty),0) into sold from dealz_claims c join feature_orders o on o.id=c.order_id where c.listing_id=l.id and c.user_id=p_customer and o.status<>'Cancelled' and o.id<>oid;
      if sold + p_qty > coalesce((a->>'perUser')::int,1) then raise exception 'claim limit reached for this deal'; end if;
      if now() < (a->>'start')::timestamptz or now() > (a->>'end')::timestamptz then raise exception 'this deal is not active'; end if;
      insert into dealz_claims(order_id,listing_id,user_id,code) values (oid,l.id,p_customer,upper(substr(md5(gen_random_uuid()::text),1,8)));
    when 'prezo' then insert into prezo_orders(order_id,recipient,message,deliver_on,gift_wrap,anonymous) values (oid,coalesce(d->'recipient','{}'),left(d->>'message',coalesce((a->>'personalMax')::int,500)),nullif(d->>'deliver_on','')::date,coalesce((d->>'gift_wrap')::boolean,false),coalesce((d->>'anonymous')::boolean,false));
    when 'globiz' then insert into globiz_inquiries(order_id,listing_id,message) values (oid,l.id,d->>'message');
    when 'lutz' then
      select coalesce(max(t.n),0) into k from lutz_ticket_numbers t where t.listing_id=l.id;
      if k + p_qty > (a->>'total')::int then raise exception 'not enough raffle tickets left'; end if;
      insert into lutz_ticket_numbers(listing_id,n,order_id) select l.id, k+g, oid from generate_series(1,p_qty) g;
    when 'frenzies' then
      select count(*) into k from frenzies_entries where listing_id=l.id;
      if k >= (a->>'players')::int then raise exception 'this tournament is full'; end if;
      insert into frenzies_entries(order_id,listing_id,player) values (oid,l.id,p_customer);
    else null;
  end case;

  if amt > 0 then
    fee := round(amt * fee_rate(l.feature), 2);
    insert into wallet_ledger(business_id,feature,type,status,amount,ref_table,ref_id,idempotency_key,label) values
      (l.business_id,l.feature,'sale','pending',amt,'feature_orders',oid,'sale-'||oid,'Order · '||l.title),
      (l.business_id,l.feature,'fee','pending',-fee,'feature_orders',oid,'fee-'||oid,'Platform fee');
  end if;
  perform log_event(l.business_id, l.feature, 'order_placed', 'New order: '||l.title, jsonb_build_object('view','feat','arg',l.feature));
  perform notify(l.business_id, l.feature, 'order', 'New order: '||l.title, jsonb_build_object('view','feat','arg',l.feature));
  return oid;
end $$;

-- ===== Auctions and raffles =====
create or replace function place_bid(p_listing uuid, p_bidder uuid, p_amount numeric) returns timestamptz language plpgsql security definer set search_path=public as $$
declare l listings; a jsonb; st timestamptz; en timestamptz; top numeric; inc numeric; need numeric;
begin
  select * into l from listings where id=p_listing for update;
  if not found or l.feature<>'bidz' or l.status<>'published' then raise exception 'this auction is not available'; end if;
  if exists(select 1 from business_members where business_id=l.business_id and user_id=p_bidder) then raise exception 'you cannot bid on your own auction'; end if;
  a := l.attributes; st := (a->>'startAt')::timestamptz; inc := coalesce((a->>'inc')::numeric,1);
  insert into bidz_state(listing_id, ends_at) values (l.id, st + make_interval(hours=>(a->>'hours')::int)) on conflict do nothing;
  select ends_at into en from bidz_state where listing_id=l.id;
  if now() < st or now() >= en then raise exception 'this auction is not live'; end if;
  select max(amount) into top from bidz_bids where listing_id=l.id;
  need := case when top is null then (a->>'start')::numeric else top + inc end;
  if p_amount < need then raise exception 'bid at least %', need; end if;
  insert into bidz_bids(listing_id,bidder,amount) values (l.id,p_bidder,p_amount);
  if coalesce((a->>'autoExtend')::boolean,false) and en - now() < interval '5 minutes' then update bidz_state set ends_at = ends_at + interval '5 minutes' where listing_id=l.id returning ends_at into en; end if;
  return en;
end $$;

create or replace function close_auction(p_listing uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare l listings; en timestamptz; w bidz_bids; oid uuid;
begin
  select * into l from listings where id=p_listing for update;
  select ends_at into en from bidz_state where listing_id=p_listing;
  if not found or now() < en then raise exception 'the auction is still running'; end if;
  if l.status<>'published' then return null; end if;
  select * into w from bidz_bids where listing_id=p_listing order by amount desc, at limit 1;
  update listings set status='archived' where id=p_listing;
  if w.id is null or w.amount < coalesce((l.attributes->>'reserve')::numeric, 0) then return null; end if;     -- no bids, or reserve not met
  update listings set status='published' where id=p_listing;                                                   -- place_order needs a live listing
  oid := place_order(p_listing, w.bidder, null, 1, null, jsonb_build_object('amount', w.amount), 'auction-'||p_listing);
  update listings set status='archived' where id=p_listing;
  return oid;
end $$;

create or replace function draw_raffle(p_listing uuid) returns int language plpgsql security definer set search_path=public as $$
declare l listings; sold int; w record;
begin
  select * into l from listings where id=p_listing and feature='lutz' for update;
  if not found or l.status<>'published' then raise exception 'raffle not available'; end if;
  if (l.attributes->>'drawAt')::timestamptz > now() then raise exception 'it is not draw time yet'; end if;
  if exists(select 1 from raffle_draws where listing_id=p_listing) then raise exception 'this raffle was already drawn'; end if;
  select count(*) into sold from lutz_ticket_numbers where listing_id=p_listing;
  if sold < coalesce((l.attributes->>'minSold')::int,1) then raise exception 'not enough tickets were sold to run the draw'; end if;
  select t.n, t.order_id into w from lutz_ticket_numbers t where t.listing_id=p_listing order by gen_random_uuid() limit 1;   -- uuid v4 is cryptographically random
  insert into raffle_draws(listing_id,winning_n,order_id) values (p_listing,w.n,w.order_id);
  perform log_event(l.business_id, 'lutz', 'raffle_drawn', 'Raffle drawn: '||l.title||' (ticket '||w.n||')');
  return w.n;
end $$;

-- ===== Privileges =====
do $$ declare r record;
begin
  for r in select p.oid::regprocedure as sig, p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public'
    and p.proname in ('is_owner','record_transfer','settle_payout','ledger_refund','cancel_order','place_order','place_bid','close_auction','draw_raffle','refund_order','advance_order','dashboard_summary') loop
    execute format('revoke all on function %s from public, anon, authenticated', r.sig);
    if r.proname in ('is_owner','cancel_order','refund_order','advance_order','dashboard_summary') then execute format('grant execute on function %s to authenticated', r.sig); end if;
    execute format('grant execute on function %s to service_role', r.sig);
  end loop;
end $$;
revoke all on all tables in schema public from anon;

// Sends a push notification when a row is inserted into `notifications`.
// Trigger: Supabase Database Webhook on INSERT into public.notifications. Header x-webhook-secret must equal PUSH_WEBHOOK_SECRET.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async req => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('PUSH_WEBHOOK_SECRET')) return new Response('forbidden', { status: 403 });
  const { record } = await req.json();
  if (!record?.user_id) return new Response('ignored');
  const { data: pref } = await admin.from('notification_prefs').select('push').eq('user_id', record.user_id).maybeSingle();
  if (pref && pref.push === false) return new Response('push off');
  const { data: tokens } = await admin.from('push_tokens').select('token').eq('user_id', record.user_id);
  if (!tokens?.length) return new Response('no tokens');
  const link = record.link ?? {};
  const messages = tokens.map(t => ({ to: t.token, title: record.title, body: record.body ?? undefined, sound: 'default', data: { feature: record.feature ?? (link.view === 'feat' ? link.arg : undefined), page: link.view === 'onboard' ? 'registration' : link.view === 'promo' ? 'promotions' : undefined } }));
  const res = await fetch('https://exp.host/--/api/v2/push/send', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(messages) });
  const out = await res.json().catch(() => ({}));
  // drop tokens the device no longer accepts
  const dead = (out.data ?? []).map((r: any, i: number) => (r?.details?.error === 'DeviceNotRegistered' ? tokens[i].token : null)).filter(Boolean);
  if (dead.length) await admin.from('push_tokens').delete().in('token', dead);
  return new Response('sent');
});

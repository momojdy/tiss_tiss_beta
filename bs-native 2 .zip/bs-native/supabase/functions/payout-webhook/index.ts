// Provider webhook. Verifies the signature, ignores duplicate deliveries, then reconciles the ledger.
//   account.updated            -> payout destination verified
//   payout.paid                -> bank payout confirmed   (ledger: processing -> completed)
//   payout.failed / canceled   -> failed before completion, or a reversal event if it had completed
//   transfer.reversed          -> same as failed
import Stripe from 'https://esm.sh/stripe@14?target=denonext';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2024-06-20' });
const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async req => {
  const sig = req.headers.get('stripe-signature');
  if (req.method !== 'POST' || !sig) return new Response('bad request', { status: 400 });
  let ev: Stripe.Event;
  try { ev = await stripe.webhooks.constructEventAsync(await req.text(), sig, Deno.env.get('STRIPE_WEBHOOK_SECRET')!); }
  catch { return new Response('bad signature', { status: 400 }); }

  const { error: dup } = await admin.from('webhook_events').insert({ id: ev.id });
  if (dup) return new Response(dup.code === '23505' ? 'duplicate' : dup.message, { status: dup.code === '23505' ? 200 : 500 });

  try {
    const obj = ev.data.object as any;
    const ledger = obj.metadata?.ledger_id as string | undefined;
    if (ev.type === 'account.updated' && obj.payouts_enabled && obj.details_submitted) {
      const { error } = await admin.rpc('confirm_payout_method', { p_account: obj.id, p_last4: obj.external_accounts?.data?.[0]?.last4 ?? null });
      if (error) throw error;
    } else if (ev.type === 'payout.paid' && ledger) {
      const { error } = await admin.rpc('settle_payout', { p_ledger: ledger, p_status: 'completed' }); if (error) throw error;
    } else if ((ev.type === 'payout.failed' || ev.type === 'payout.canceled' || ev.type === 'transfer.reversed') && ledger) {
      const { error } = await admin.rpc('settle_payout', { p_ledger: ledger, p_status: 'failed' }); if (error) throw error;
    }
    return new Response('ok');
  } catch (e) {
    console.error('payout-webhook', ev.type, e);
    await admin.from('webhook_events').delete().eq('id', ev.id);     // let the provider retry
    return new Response('retry', { status: 500 });
  }
});

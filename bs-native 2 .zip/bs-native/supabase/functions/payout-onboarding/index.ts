// Starts provider-hosted payout onboarding (Stripe Connect Express shown; swap for your provider).
// Bank details are entered on the provider's page, never in our app or database.
// Secrets: STRIPE_SECRET_KEY, ALLOWED_RETURN_ORIGINS (comma separated, e.g. https://app.wantiss.com), ALLOWED_RETURN_PATH (default /business)
import Stripe from 'https://esm.sh/stripe@14?target=denonext';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2024-06-20' });
const SB_URL = Deno.env.get('SUPABASE_URL')!;
const ORIGINS = (Deno.env.get('ALLOWED_RETURN_ORIGINS') ?? '').split(',').map(s => s.trim()).filter(Boolean);
const PATH = Deno.env.get('ALLOWED_RETURN_PATH') ?? '/business';

const json = (body: unknown, status: number, origin: string | null) =>
  new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json', ...(origin && ORIGINS.includes(origin) ? { 'Access-Control-Allow-Origin': origin, 'Vary': 'Origin' } : {}) } });

/** Only trusted Wantiss origins and routes may receive the provider redirect. */
function safeReturn(raw: unknown): string | null {
  try {
    const u = new URL(String(raw));
    const local = u.hostname === 'localhost' || u.hostname === '127.0.0.1';
    if (!ORIGINS.includes(u.origin) || !u.pathname.startsWith(PATH) || (u.protocol !== 'https:' && !local)) return null;
    u.hash = ''; u.username = ''; u.password = '';
    return u.toString();
  } catch { return null; }
}

Deno.serve(async req => {
  const origin = req.headers.get('Origin');
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: origin && ORIGINS.includes(origin) ? { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Methods': 'POST', 'Access-Control-Allow-Headers': 'authorization, content-type, apikey', 'Vary': 'Origin' } : {} });
  }
  if (req.method !== 'POST') return json({ error: 'method not allowed' }, 405, origin);
  const auth = req.headers.get('Authorization');
  if (!auth) return json({ error: 'sign in first' }, 401, origin);
  try {
    const { business_id, return_url } = await req.json();
    const ret = safeReturn(return_url);
    if (!ret || typeof business_id !== 'string') return json({ error: 'invalid request' }, 400, origin);

    const user = createClient(SB_URL, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: auth } } });
    const { data: owner } = await user.rpc('is_owner', { b: business_id });
    if (!owner) return json({ error: 'only the business owner can set up payouts' }, 403, origin);

    const admin = createClient(SB_URL, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const { data: pm } = await admin.from('payout_methods').select('provider_account_id').eq('business_id', business_id).maybeSingle();
    let acct = pm?.provider_account_id as string | undefined;
    if (!acct) {
      // manual payout schedule: only payouts we create (with a ledger id) ever reach the bank
      const a = await stripe.accounts.create({ type: 'express', metadata: { business_id }, settings: { payouts: { schedule: { interval: 'manual' } } } }, { idempotencyKey: `acct-${business_id}` });
      acct = a.id;
      await admin.from('payout_methods').insert({ business_id, provider: 'stripe', provider_account_id: acct, status: 'pending' });
    }
    const link = await stripe.accountLinks.create({ account: acct, refresh_url: ret, return_url: ret, type: 'account_onboarding' });
    return json({ url: link.url }, 200, origin);
  } catch (e) {
    console.error('payout-onboarding', e);
    return json({ error: 'could not start payout setup' }, 500, origin);
  }
});

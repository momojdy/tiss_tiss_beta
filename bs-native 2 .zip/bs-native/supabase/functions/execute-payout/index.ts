// Sends the money in two steps and leaves the ledger as 'processing' until the bank payout is confirmed by webhook.
//   1. transfer from the platform to the vendor's connected account   (idempotency key: transfer-<ledger id>)
//   2. payout from the connected account to their bank, tagged with the ledger id (idempotency key: payout-<ledger id>)
// Trigger: Supabase Database Webhook on INSERT into wallet_ledger. Header x-webhook-secret must match PAYOUT_WEBHOOK_SECRET.
import Stripe from 'https://esm.sh/stripe@14?target=denonext';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY')!, { apiVersion: '2024-06-20' });
const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

Deno.serve(async req => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('PAYOUT_WEBHOOK_SECRET')) return new Response('forbidden', { status: 403 });
  const { record } = await req.json();
  if (!record || record.type !== 'payout' || record.status !== 'processing') return new Response('ignored');
  if (record.method === 'wal') return new Response('wallet transfers are handled by the Wantiss wallet service');   // see wallet_transfers
  const id = record.id as string;
  const cents = Math.round(Math.abs(Number(record.amount)) * 100);
  let transfer: Stripe.Transfer | null = null;
  try {
    const { data: pm } = await admin.from('payout_methods').select('provider_account_id').eq('business_id', record.business_id).eq('status', 'verified').maybeSingle();
    if (!pm) throw new Error('no verified payout method');
    const { data: biz } = await admin.from('businesses').select('currency').eq('id', record.business_id).single();
    const currency = (biz?.currency ?? 'USD').toLowerCase();

    transfer = await stripe.transfers.create({ amount: cents, currency, destination: pm.provider_account_id, metadata: { ledger_id: id } }, { idempotencyKey: `transfer-${id}` });
    await admin.rpc('record_transfer', { p_ledger: id, p_transfer: transfer.id });
    try {
      await stripe.payouts.create({ amount: cents, currency, metadata: { ledger_id: id } }, { stripeAccount: pm.provider_account_id, idempotencyKey: `payout-${id}` });
    } catch (e) {
      // Funds not yet available on the connected account: keep 'processing' and let the webhook retry later.
      if ((e as { code?: string }).code === 'balance_insufficient') return new Response('retry later', { status: 503 });
      await stripe.transfers.createReversal(transfer.id, {}, { idempotencyKey: `reverse-${id}` });   // permanent failure: take the money back
      throw e;
    }
    return new Response('submitted');            // completion arrives via payout.paid
  } catch (e) {
    console.error('execute-payout', id, e);
    await admin.rpc('settle_payout', { p_ledger: id, p_status: 'failed' });
    return new Response('failed', { status: 200 });   // handled: the ledger now shows the failure and funds are released
  }
});
